package Vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Controleur.MasterIHM;
import Modele.Utile;
import file.Load;

public class DrawSave extends PageMaster {

	private static final long serialVersionUID = 1L;
	
	private Bouton aBack;
	private Bouton aNext;
	private Bouton aPrevious;
	private Bouton aDelete;
	private Bouton aContinue;
	
	private int aNoSave;
	
	public DrawSave( MasterIHM pControleur) {
		super( pControleur);
		
		this.aNoSave = 0;
		
		initialize();		
	}


	protected void initialize() 
	{
		
		this.setLayout( new BorderLayout() );
		
		this.aBack = new Bouton("Retour",400,40, this.aCOLOR_LIGHT_GREY);
		this.aNext = new Bouton("Suivant",600,40, this.aCOLOR_LIGHT_GREY);
		this.aPrevious = new Bouton("Precedent",600,40, this.aCOLOR_LIGHT_GREY);
		this.aDelete = new Bouton("Supprimer",400,40, this.aCOLOR_LIGHT_GREY);
		this.aContinue = new Bouton("Continuer",400,40, this.aCOLOR_LIGHT_GREY);
		this.aSouth = new JPanel();
		this.aCenter = new JPanel();
		

		
	}

	protected void add(int pNoSave) 
	{	
		this.removeAll();

		this.aNoSave = pNoSave;
		drawCenter();
		drawSouthBar();
		

	}
	
	private void drawCenter()
	{
		Load load = new Load(this.aNoSave);
		
		this.aCenter.setLayout( new GridLayout(1,2) );
		
		
		JPanel westPan = new JPanel();
		westPan.setBackground(aCOLOR_DARK_GREY);

		westPan.setLayout( new GridLayout(3,1) );
		
		JLabel noSave = new JLabel("Sauvegarde numero : " + this.aNoSave + "        ");
		JLabel mode = new JLabel( "Mode : " + load.getMode() );
		JLabel noTurn = new JLabel( "Tour numero : " + load.getNoTurn() );
		
		noSave.setFont( new Font("Arial",Font.BOLD,22) );
		mode.setFont( new Font("Arial",Font.PLAIN,18) );
		noTurn.setFont( new Font("Arial",Font.PLAIN,18) );

		noSave.setForeground(new Color(255,255,255));
		mode.setForeground(new Color(255,255,255));
		noTurn.setForeground(new Color(255,255,255));
		
		
		westPan.add(noSave);
		westPan.add(mode);
		westPan.add(noTurn);
			
		JPanel eastPan = new JPanel();
		eastPan.setBackground(aCOLOR_DARK_GREY);

		imagePanel imgPlateau[][] = new imagePanel[11][11];
		String[][] strPlateau = Utile.PlateauToString( load.getPlateau() );
		
		

		GridLayout grid = new GridLayout(11,11);
		eastPan.setLayout( grid );

		for (int l = 0; l < 11; l++)
		{
			for (int c = 0; c < 11; c++)
			{
				imgPlateau[l][c] = new imagePanel( "img/" + strPlateau[l][c] + ".png" );
				eastPan.add( imgPlateau[l][c] );
			}
		}
		
		this.add(this.aCenter, BorderLayout.CENTER);
		this.aCenter.add(westPan);
		this.aCenter.add(eastPan);
	}
	public void drawSouthBar()
	{
		GridLayout southGrid = new GridLayout(2,1,20,20);
		this.aSouth.setLayout(southGrid);
		this.aSouth.setBackground(aCOLOR_DARK_GREY);

		
		JPanel southPan1 = new JPanel();
		JPanel southPan2 = new JPanel();
		southPan1.setLayout( new GridLayout(1,2,10,10) );
		southPan2.setLayout( new GridLayout(1,3,10,10) );
		southPan1.setBackground(aCOLOR_DARK_GREY);
		southPan2.setBackground(aCOLOR_DARK_GREY);

		
		
		this.add(this.aSouth, BorderLayout.SOUTH);
			this.aSouth.add(southPan1);
				southPan1.add(this.aNext,BorderLayout.WEST);
				southPan1.add(this.aPrevious,BorderLayout.EAST);
			this.aSouth.add(southPan2);
				southPan2.add(this.aContinue, BorderLayout.EAST);
				southPan2.add(this.aBack, BorderLayout.CENTER);
				southPan2.add(this.aDelete, BorderLayout.WEST);
	}
	
	protected void listeners() 
	{
		aBack.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mSaves_Back();
	         }
		});
		
		aNext.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mSaves_Next( aNoSave );
	         }
		});
		
		aPrevious.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mSaves_Previous( aNoSave );
	         }
		});
		
		aDelete.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mSaves_Delete( aNoSave );
	         }
		});
		
		aContinue.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mSaves_Continue( aNoSave );
	         }
		});
		
	}
}
