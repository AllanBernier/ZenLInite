package Vue;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class imagePanel extends JPanel {
	
	private static final long serialVersionUID = 2064791986261931804L;

	ImageIcon image;
	
	public imagePanel(String pPath)
	{
		super();
		//this.setLayout( new GridLayout(1,1) );

		//this.setBackground(new Color(45,45,45));

		image = new ImageIcon(pPath);	
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		this.setLayout(new BorderLayout() );

		g.drawImage(image.getImage() , 0, 0, getWidth(), getHeight(), null);
		this.setPreferredSize(new Dimension(500,500));
	}
	
}
