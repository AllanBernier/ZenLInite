package Vue;


import javax.swing.JComponent;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Bouton extends JComponent {

	private static final long serialVersionUID = 1L;
	
	private final String name;
    private boolean isClick;
    private int aX;
    private int aY;
    private Color aColor;
    
    public Bouton(String pName, int pX, int pY, Color pColor) {
    	
    	this.aX = pX;
    	this.aY = pY;
    	this.aColor = pColor;
    	
    	this.setPreferredSize(new Dimension(aX, aY));

        this.name = pName;
        this.isClick = false;

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            	Bouton.this.isClick = true;
            	Bouton.this.repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	Bouton.this.isClick = false;
            	Bouton.this.repaint();
            }
        });

    }

    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        g2d.setColor( this.aColor );
        g2d.fillRect(0, 0, aX, aY);
        g2d.setColor(new Color(255,255,255));

        
        g2d.setFont(new Font("Arial", Font.ITALIC, 12));
        g2d.setFont(this.isClick ? new Font("Arial", Font.ITALIC, 12) : new Font("Arial", Font.ITALIC, 14));
        
        
        FontMetrics metrics = g.getFontMetrics();
        int x = (aX  - metrics.stringWidth(this.name)) / 2;
        int y = (aY  - metrics.getHeight()) / 2 + metrics.getAscent();

        g2d.drawString(this.name, x, y);

        
    }
    
    public boolean isClicked()
    {
    	return this.isClick;
    }
    
}
