package Vue;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JPanel;

import Controleur.MasterIHM;


public class DrawHub extends PageMaster{


	private static final long serialVersionUID = 1L;
	
	Bouton aPvP;
	Bouton aPvIA;
	Bouton a2Pv2P;
	Bouton aSaves;
	Bouton aRules;
	Bouton aCredits;
	Bouton aQuit;
	
	
	public DrawHub( MasterIHM pControleur)
	{
		super( pControleur);
	
		initialize();
	}
	
	
	public void initialize()
	{
		this.setLayout(new BorderLayout() );
		this.aWest = new JPanel();
		this.aWest.setLayout(new BorderLayout() );		
		GridLayout gridBoutons = new GridLayout(7,1,0,20);
		this.aWest.setLayout( gridBoutons );
		this.aWest.setBackground(aCOLOR_DARK_GREY);
		
		
		this.aPvP = new Bouton("Joueur vs Joueur",350,40, aCOLOR_LIGHT_GREY);
		this.aPvIA = new Bouton("Joueur vs IA",350,40, aCOLOR_LIGHT_GREY);
		this.a2Pv2P = new Bouton("2 Joueurs vs 2 Joueurs",350,40, aCOLOR_LIGHT_GREY);
		this.aSaves = new Bouton("Sauvegardes",350,40, aCOLOR_LIGHT_GREY);
		this.aRules = new Bouton("Regles",350,40, aCOLOR_LIGHT_GREY);
		this.aCredits = new Bouton("Credits",350,40, aCOLOR_LIGHT_GREY);
		this.aQuit = new Bouton("Quitter",350,40, aCOLOR_LIGHT_GREY);
		 
		this.aCenter = new imagePanel("img/accueil_BackGround.png");

	}
	
	public void add()
	{
		this.removeAll();

		this.add(this.aWest, BorderLayout.WEST);
			this.aWest.add(this.aPvP);
			this.aWest.add(this.aPvIA);
			this.aWest.add(this.a2Pv2P);
			this.aWest.add(this.aSaves);
			this.aWest.add(this.aRules);
			this.aWest.add(this.aCredits);
			this.aWest.add(this.aQuit);
		this.add(this.aCenter, BorderLayout.CENTER);
			this.add(this.aCenter);
		

	}
	

	public void listeners()
	{
		aPvP.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_PlayerVsPlayer();
	         }
		});
		
		aPvIA.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_PlayerVsIA();
	         }
		});
		
		a2Pv2P.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_2PlayersVs2Players();
	         }
		});
		
		aSaves.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_Saves();
	         }
		});
		
		aRules.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_Rules();
	         }
		});
		
		aCredits.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_Credits();
	         }
		});
		
		aQuit.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mMenu_Quitter();
	         }
		});
	}
}
