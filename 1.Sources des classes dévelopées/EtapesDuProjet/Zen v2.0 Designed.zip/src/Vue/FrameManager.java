package Vue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controleur.MasterIHM;

public class FrameManager extends JFrame{
	private MasterIHM aControleur; 
	
	private DrawCredits aCredits;
	private DrawHub aHub;
	private DrawSave aSave;
	private DrawGame aGame;
	
	private JPanel aCurrentPan;
	
	private static final long serialVersionUID = -3608560151397303411L;
	
	public FrameManager(String pTitre)
	{
		super(pTitre);
		this.getDefaultCloseOperation();
		this.pack();
		this.setSize(1200, 600);
		this.setVisible(true);
		this.aControleur = new MasterIHM(this);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		this.aCredits = new DrawCredits(this.aControleur);
		this.aSave = new DrawSave(this.aControleur);
		//this.aGame = new DrawGame(this.aControleur);
		this.aHub = new DrawHub(this.aControleur);
		
		mDrawHub();
	}
	
	public void mDrawCredits()
	{
		this.aCredits.initialize();
		this.aCredits.add();
		this.aCredits.listeners();
		this.aCurrentPan = this.aCredits;

		mUpdate();
	}
	
	public void mDrawSave(int pNoSave)
	{
		this.aSave.initialize();
		this.aSave.add(pNoSave);
		this.aSave.listeners();
		this.aCurrentPan = this.aSave;
 
		 mUpdate();
	}
	
	public void mDrawGame(String[][] pStrGrid)
	{
		new DrawGame(this, this.aControleur, pStrGrid);
	}
	
	public void mDrawHub()
	{
		this.aHub.initialize();
		this.aHub.add();
		this.aHub.listeners();
		this.aCurrentPan = this.aHub;
		 mUpdate();
	}
	
	public void mUpdate()
	{
		this.setContentPane( this.aCurrentPan );
		this.repaint();
		this.revalidate();
	}
	
}









