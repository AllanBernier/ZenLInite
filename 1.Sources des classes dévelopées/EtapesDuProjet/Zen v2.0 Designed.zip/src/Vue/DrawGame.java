package Vue;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Controleur.MasterIHM;

public class DrawGame extends PageMaster {

	private static final long serialVersionUID = 1L;
	
	private Bouton aLobby;
	private Bouton aRules;
	private Bouton aSave;
	private imagePanel[][] aGrid;
	private String[][] aStrGrid;
	
	private JPanel aPanButton;
	private JPanel aPanAffichage;
	
	private FrameManager aFrame;
	
	public DrawGame(FrameManager pFrame, MasterIHM pControleur, String[][] pGrid) {
		super(pControleur);

		this.aFrame = pFrame;
		this.aStrGrid = pGrid;
		
		initialize();
		add();
		listeners();
		

		this.aFrame.setContentPane(this);
		this.aFrame.repaint();
		this.aFrame.revalidate();
	}

	protected void initialize() {
		
		this.setLayout( new BorderLayout() );

		this.aCenter = new JPanel( new GridLayout(11,11));
		
		this.aCenter.setBackground(aCOLOR_DARK_GREY);

		
		this.aWest = new JPanel( new BorderLayout() );		
		this.aWest.setBackground(aCOLOR_DARK_GREY);

		
		
		this.aLobby = new Bouton("Accueil", 300,40, aCOLOR_LIGHT_GREY);
		this.aRules = new Bouton("Regles", 300,40, aCOLOR_LIGHT_GREY);
		this.aSave  = new Bouton("Sauvegarde", 300,40, aCOLOR_LIGHT_GREY);
		

		
		this.aGrid = new imagePanel[11][11]; 
		
		for (int l = 0; l < 11; l++)
		{
			for (int c = 0; c < 11; c++)
			{
				System.out.print("img/" + this.aStrGrid[l][c] + ".png" + "\t");
				this.aGrid[l][c] = new imagePanel("img/" + this.aStrGrid[l][c] + ".png");
			}
		}
		
		this.aPanButton = new JPanel(new BorderLayout() );
		this.aPanAffichage = new JPanel(new BorderLayout() );
	}

	protected void add() {
				
		drawPlateau();
		drawButton();
	
				
		this.aPanAffichage.add(this.aPanButton);
		this.aWest.add( this.aPanAffichage,BorderLayout.SOUTH );
	
		this.add( this.aCenter, BorderLayout.CENTER);
		

		// Affichage des infos en jeu (a venir)
		
		JPanel info = new JPanel( new BorderLayout() );
		
		this.aPanAffichage.add(this.aPanButton, BorderLayout.NORTH);
		this.aPanAffichage.add(new JLabel(""), BorderLayout.SOUTH);
		this.aPanAffichage.add(new JLabel(""), BorderLayout.EAST);
		this.aPanAffichage.add(new JLabel(""), BorderLayout.WEST);
		this.aPanAffichage.add(info		 	 , BorderLayout.CENTER);

		info.add(new Bouton("Texte a venir :)", 300,375, aCOLOR_LIGHT_GREY), BorderLayout.CENTER);

		
		
		// Placement final des elements
		this.aNorth.add( new JLabel("") );
		this.add( this.aNorth , BorderLayout.NORTH);

		this.aSouth.add( new JLabel("") );
		this.add( this.aSouth , BorderLayout.SOUTH);
		this.aEast.add( new JLabel(" ") );
		this.add( this.aEast , BorderLayout.EAST);
		this.add( this.aWest, BorderLayout.WEST);
	}

	
	private void drawPlateau()
	{
		for (int l = 0; l < 11; l++)
		{
			for (int c = 0; c < 11; c++)
			{
				this.aCenter.add( this.aGrid[l][c] ); 
			}
		}
	}
	
	private void drawButton()
	{
		JPanel p1 = new JPanel(new BorderLayout() );
		JPanel p2 = new JPanel(new BorderLayout() );
		JPanel p3 = new JPanel(new BorderLayout() );
		JPanel p4 = new JPanel(new BorderLayout() );

		this.aNorth = new JPanel();
		this.aSouth = new JPanel();
		this.aEast = new JPanel();
		
		p1.setBackground(aCOLOR_DARK_GREY);
		p2.setBackground(aCOLOR_DARK_GREY);
		p3.setBackground(aCOLOR_DARK_GREY);
		p4.setBackground(aCOLOR_DARK_GREY);
		
		this.aNorth.setBackground(aCOLOR_DARK_GREY);
		this.aSouth.setBackground(aCOLOR_DARK_GREY);
		this.aEast.setBackground(aCOLOR_DARK_GREY);

		
		
		p1.add(this.aLobby,BorderLayout.NORTH);
		p1.add(new JLabel("  "), BorderLayout.CENTER);
		p1.add(p2,BorderLayout.SOUTH);

		
		
		p2.add(this.aRules,BorderLayout.NORTH);
		p2.add(new JLabel("  "), BorderLayout.CENTER);
		p2.add(p3,BorderLayout.SOUTH);

		
		p3.add(this.aSave,BorderLayout.NORTH);
		p3.add(new JLabel("  "), BorderLayout.CENTER);
		p3.add(p4,BorderLayout.SOUTH);
		
		this.aPanButton.add(p1, BorderLayout.CENTER);

		this.aWest.add(this.aPanButton, BorderLayout.NORTH);
		
	}
	
	
	protected void listeners() {
		aLobby.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mGame_Hub();
	         }
		});
		
		aRules.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mGame_Rules();
	         }
		});
		
		aSave.addMouseListener( new java.awt.event.MouseAdapter()
		{ 
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mGame_Save();
	         }
		});
		
		for (int l = 0; l < 11; l++)
		{
			for (int c = 0; c < 11; c++)
			{
				int line = l;
				int column = c;
				aGrid[l][c].addMouseListener( new java.awt.event.MouseAdapter()
				{
			         @Override
			         public void mouseReleased(java.awt.event.MouseEvent evt) 
			         {
			        	 aControleur.mCaseClicked(line, column);
			         }
				});
			}
		}
		
	}

}
