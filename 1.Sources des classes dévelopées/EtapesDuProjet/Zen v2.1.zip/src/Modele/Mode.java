package Modele;

public enum Mode {
	  PvP,
	  PvIA,
	  PvP4Joueurs;	
}
