package Vue;

import java.awt.Color;

import javax.swing.JPanel;

import Controleur.MasterIHM;

abstract class PageMaster extends JPanel{

	private static final long serialVersionUID = 1L;
	
	public MasterIHM aControleur;
	
	
	protected JPanel aNorth;
	protected JPanel aSouth;
	protected JPanel aEast;
	protected JPanel aWest;
	protected JPanel aCenter;

	protected final Color aCOLOR_DARK_GREY = new Color(45,45,45);
	protected final Color aCOLOR_LIGHT_GREY = new Color(120,120,120);
	
	public PageMaster(MasterIHM pControleur)
	{
		super();
		
		this.aControleur = pControleur;
		
		
	}
}
