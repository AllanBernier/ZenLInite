package Vue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Controleur.MasterIHM;

public class FrameManager extends JFrame{
	
	private static final long serialVersionUID = -3608560151397303411L;

	private MasterIHM aControleur; 
	private DrawCredits aCredits;
	private DrawHub aHub;
	private DrawSave aSave;
	private JPanel aCurrentPan;
	private boolean aToolClicked;
	
	public FrameManager(String pTitre)
	{
		super(pTitre);
		this.getDefaultCloseOperation();
		this.pack();
		this.setSize(1200, 600);
		this.setVisible(true);
		this.aControleur = new MasterIHM(this);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		aToolClicked = false;
		
		this.aCredits = new DrawCredits(this.aControleur);
		this.aSave = new DrawSave(this.aControleur);
		this.aHub = new DrawHub(this.aControleur);
		
		mDrawHub();
	}
	
	public void mDrawCredits()
	{
		this.aCredits.initialize();
		this.aCredits.add();
		this.aCredits.listeners();
		this.aCurrentPan = this.aCredits;

		mUpdate();
	}
	
	public void mDrawSave(int pNoSave)
	{
		this.aSave.initialize();
		this.aSave.add(pNoSave);
		this.aSave.listeners();
		this.aCurrentPan = this.aSave;
 
		 mUpdate();
	}
	
	
	/**
	 * Change le Jpanel actuel avec le jpanel correspondant au jeu, peut importe le mode (PvP, PvIA ..) 
	 * @param pStrGrid Correspond aux images qu'il faut afficher.
	 * @param pToolType Cette attribut permet de choisir ce qui sera afficher dans le petit encadr� en bas a droite de l'ecran
	 * 1 = infos sur le jeu.
	 * 2 = sauvegardes.
	 * 3 = regles.
	 */
	public void mDrawGame(String[][] pStrGrid)
	{
		aToolClicked = false;
		aCurrentPan = DrawGames.getGamePanel(this.aControleur, pStrGrid,aToolClicked);
		 mUpdate();
	}
	
	public void mDrawHub()
	{
		this.aHub.initialize();
		this.aHub.add();
		this.aHub.listeners();
		this.aCurrentPan = this.aHub;
		 mUpdate();
	}
	
	public void mDrawGameRules(String[][] pStrGrid, int pNoRule)
	{
		aToolClicked = true;
		aCurrentPan = DrawGames.getGamePanel_Rule(this.aControleur, pStrGrid, pNoRule,aToolClicked);
		mUpdate();
	}
	
	public void mDrawGameSave(String[][] pStrGrid, int pNoRule)
	{
		aToolClicked = true;
		aCurrentPan = DrawGames.getGamePanel_Save(this.aControleur, pStrGrid, pNoRule,aToolClicked);
		mUpdate();
	}
	
	public void mDrawRules()
	{
		aCurrentPan = DrawRules.getRulesPanel(this.aControleur);
		mUpdate();
	}
	
	public void mUpdate()
	{
		this.setContentPane( this.aCurrentPan );
		this.repaint();
		this.revalidate();
	}
	
}









