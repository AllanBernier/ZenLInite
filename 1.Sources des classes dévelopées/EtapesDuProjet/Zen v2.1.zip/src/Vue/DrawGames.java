package Vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Controleur.MasterIHM;
import Modele.Utile;
import file.Load;

public class DrawGames 
{
	private static Color COLOR_DARK_GREY = new Color(45,45,45);
	private static Color COLOR_LIGHT_GREY = new Color(120,120,120);
	
	
	
	public static JPanel getGamePanel(MasterIHM pControleur, String[][] pStrGrid, boolean pRulesClicked)
	{

		
		JPanel gamePan = new JPanel(new BorderLayout());
		JPanel gridPan = mDrawGrid( pStrGrid, pControleur);
		JPanel westPan = new JPanel(new BorderLayout() );
		JPanel bouton = mDrawButtons( pControleur, pRulesClicked);
		JPanel toolGame = mDrawToolGame( pControleur);
		
		gamePan.add(gridPan, BorderLayout.CENTER);
		westPan.add(bouton, BorderLayout.NORTH);
		westPan.add(toolGame, BorderLayout.SOUTH);
		gamePan.add(westPan, BorderLayout.WEST);
		
		gamePan.setBackground(COLOR_DARK_GREY);
		westPan.setBackground(COLOR_DARK_GREY);
		gridPan.setBackground(COLOR_DARK_GREY);
		bouton.setBackground(COLOR_DARK_GREY);
		toolGame.setBackground(COLOR_DARK_GREY);

		
		return gamePan;
	}
	
	public static JPanel getGamePanel_Rule(MasterIHM pControleur, String[][] pStrGrid, int pNoRule, boolean pRulesClicked)
	{

		
		JPanel gamePan = new JPanel(new BorderLayout());
		JPanel gridPan = mDrawGrid( pStrGrid, pControleur);
		JPanel westPan = new JPanel(new BorderLayout() );
		JPanel bouton = mDrawButtons( pControleur, pRulesClicked);
		
		JPanel toolGame = mDrawRules(pControleur, pNoRule);
		
		gamePan.add(gridPan, BorderLayout.CENTER);
		westPan.add(bouton, BorderLayout.NORTH);
		westPan.add(toolGame, BorderLayout.CENTER);
		gamePan.add(westPan, BorderLayout.WEST);
		
		gamePan.setBackground(COLOR_DARK_GREY);
		westPan.setBackground(COLOR_DARK_GREY);
		gridPan.setBackground(COLOR_DARK_GREY);
		bouton.setBackground(COLOR_DARK_GREY);
		toolGame.setBackground(COLOR_DARK_GREY);

		
		return gamePan;
	}
	
	public static JPanel getGamePanel_Save(MasterIHM pControleur, String[][] pStrGrid, int pNoSave, boolean pRulesClicked)
	{

		System.out.println("Coco");
		
		JPanel gamePan = new JPanel(new BorderLayout());
		JPanel gridPan = mDrawGrid( pStrGrid, pControleur);
		JPanel westPan = new JPanel(new BorderLayout() );
		JPanel bouton = mDrawButtons( pControleur, pRulesClicked);
		
		JPanel toolGame = mDrawSave(pControleur, pNoSave);
		
		gamePan.add(gridPan, BorderLayout.CENTER);
		westPan.add(bouton, BorderLayout.NORTH);
		westPan.add(toolGame, BorderLayout.CENTER);
		gamePan.add(westPan, BorderLayout.WEST);
		
		gamePan.setBackground(COLOR_DARK_GREY);
		westPan.setBackground(COLOR_DARK_GREY);
		gridPan.setBackground(COLOR_DARK_GREY);
		bouton.setBackground(COLOR_DARK_GREY);
		toolGame.setBackground(COLOR_DARK_GREY);

		
		return gamePan;
	}
	
	private static JPanel mDrawGrid(String[][] pStrGrid, MasterIHM pControleur) 
	{
		imagePanel[][] imgGrid = new imagePanel[11][11];
		JPanel grid = new JPanel( new GridLayout(11,11) );
		
		for (int l = 0; l < 11; l++)
		{
			for (int c = 0; c < 11; c++)
			{
				imgGrid[l][c] = new imagePanel("img/" + pStrGrid[l][c] + ".png");
				grid.add( imgGrid[l][c] ); 
				
				int line = l;
				int column = c;
				
				imgGrid[l][c].addMouseListener( new java.awt.event.MouseAdapter()
				{
			         @Override
			         public void mouseReleased(java.awt.event.MouseEvent evt) 
			         {
			        	 pControleur.mCaseClicked(line, column);
			         }
				});
			}
		}
		
		return grid;
	}
	
	private static JPanel mDrawButtons( MasterIHM pControleur , boolean pToolClicked)
	{
		
		JPanel buttons = new JPanel(new GridLayout (4,1,10,10) );
		
		Bouton bLobby = new Bouton("Accueil", 300,40, COLOR_LIGHT_GREY);
		Bouton bRules = new Bouton("Regles", 300,40, COLOR_LIGHT_GREY);
		Bouton bSave  = new Bouton("Sauvegarde", 300,40, COLOR_LIGHT_GREY);
		
		buttons.add(bLobby);
		buttons.add(bRules);
		buttons.add(bSave);
		
		bLobby.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 pControleur.mGame_Hub();
	         }
		});
		
		bRules.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 if ( !pToolClicked)
	        	 {
	        		 pControleur.mGame_Rules(0);
	        	 }
	        	 else
	        	 {
	        		 pControleur.mDrawGame();
	        	 }
	         }
		});
		
		bSave.addMouseListener( new java.awt.event.MouseAdapter()
		{ 
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 if ( !pToolClicked)
	        	 {
	        		 pControleur.mGame_Save(0);
	        	 }
	        	 else
	        	 {
	        		 pControleur.mDrawGame();
	        	 }	         
	        }
		});
		
		return buttons;
	}
	
	private static JPanel mDrawToolGame( MasterIHM pControleur )
	{
		JPanel toolGame = new JPanel();
		toolGame.add(new Bouton("Texte a venir :)", 280,375, COLOR_LIGHT_GREY), BorderLayout.CENTER);
		
		return toolGame;
	}
	
	private static JPanel mDrawRules(MasterIHM pControleur, int pNoRule)
	{
		JPanel rules = new JPanel( new BorderLayout() );
		
		JPanel boutons = new JPanel( new GridLayout(1,2,10,10) );
			boutons.setBackground(COLOR_LIGHT_GREY);
		
			Bouton bNext = new Bouton("Suivante", 120,40, COLOR_LIGHT_GREY);
			Bouton bPrevious = new Bouton("Precedente", 120,40, COLOR_LIGHT_GREY);	
			boutons.add(bNext);
			boutons.add(bPrevious);
			
			bNext.addMouseListener( new java.awt.event.MouseAdapter()
			{
		         @Override
		         public void mouseReleased(java.awt.event.MouseEvent evt) 
		         {
		        	 pControleur.mGame_Rules(pNoRule + 1);
		         }
			});
			
			bPrevious.addMouseListener( new java.awt.event.MouseAdapter()
			{
		         @Override
		         public void mouseReleased(java.awt.event.MouseEvent evt) 
		         {
		        	 pControleur.mGame_Rules(pNoRule - 1);
		         }
			});
			
	
		rules.add(boutons, BorderLayout.NORTH);
		
			JLabel labelRule = new JLabel(Utile.mGetRulesJLabel(pNoRule));
			labelRule.setForeground(new Color(255,255,255));
			labelRule.setFont(new Font("Arial", Font.ITALIC, 15));
			
		rules.add(labelRule, BorderLayout.CENTER);
			
		return rules;
	}
	
	private static JPanel mDrawSave(MasterIHM pControleur, int pNoSave )
	{
		JPanel save = new JPanel( new BorderLayout() );
		

		
		JPanel boutons = new JPanel( new GridLayout(1,3,10,10) );
			boutons.setBackground(COLOR_LIGHT_GREY);
		
			Bouton bNext = new Bouton("Suivante", 80,40, COLOR_LIGHT_GREY);
			Bouton pSave = new Bouton("Sauvegarder", 80,40, COLOR_LIGHT_GREY);	
			Bouton bPrevious = new Bouton("Precedente", 80,40, COLOR_LIGHT_GREY);	
			boutons.add(bNext);
			boutons.add(pSave);
			boutons.add(bPrevious);
			
			bNext.addMouseListener( new java.awt.event.MouseAdapter()
			{
		         @Override
		         public void mouseReleased(java.awt.event.MouseEvent evt) 
		         {
		        	 pControleur.mGame_Save(pNoSave + 1);
		         }
			});
			
			bPrevious.addMouseListener( new java.awt.event.MouseAdapter()
			{
		         @Override
		         public void mouseReleased(java.awt.event.MouseEvent evt) 
		         {
		        	 pControleur.mGame_Save(pNoSave - 1);
		         }
			});
			
			pSave.addMouseListener( new java.awt.event.MouseAdapter()
			{
		         @Override
		         public void mouseReleased(java.awt.event.MouseEvent evt) 
		         {
		        	 pControleur.mSaveCurrentGame( pNoSave);
		        	 pControleur.mGame_Save(pNoSave);
		         }
			});
	
			save.add(boutons, BorderLayout.NORTH);
		
		JPanel infoSave = new JPanel( new BorderLayout() );
		
		JPanel backGroundLabel = new JPanel();
		JLabel lNoSave = new JLabel("Sauvegarde numero : " + pNoSave);
		
		
		backGroundLabel.setBackground(COLOR_DARK_GREY);
		lNoSave.setForeground(new Color(255,255,255));
		lNoSave.setFont(new Font("Arial", Font.ITALIC, 15));
		
		backGroundLabel.add(lNoSave);
		infoSave.add(backGroundLabel, BorderLayout.NORTH);
		
		JPanel grid = new JPanel( new GridLayout(11,11) );
		imagePanel[][] imgGrid = new imagePanel[11][11];
		
		Load myLoad = new Load(pNoSave);
		String[][] strGrid =  Utile.PlateauToString( myLoad.getPlateau() );

		
		for (int l = 0; l < 11; l++)
		{
			for (int c = 0; c < 11; c++)
			{
				imgGrid[l][c] = new imagePanel("img/" + strGrid[l][c] + ".png");
				grid.add( imgGrid[l][c] ); 
			}
		}
		
		infoSave.add(grid, BorderLayout.CENTER);
		
		save.add(infoSave,BorderLayout.CENTER);
		
		return save;
	}
}
