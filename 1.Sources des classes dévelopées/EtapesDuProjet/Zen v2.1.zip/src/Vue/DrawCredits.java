package Vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Controleur.MasterIHM;

public class DrawCredits extends PageMaster{
	

	private static final long serialVersionUID = 1L;

	private Bouton aBack;
	
	private JLabel aTitle;
	private JLabel aCredits;
		
	public DrawCredits( MasterIHM pControleur)
	{
		super(pControleur);
		
		initialize();
	}
	
	protected  void initialize()
	{
		this.setLayout(new BorderLayout() );
		this.aCenter = new JPanel();
		this.aCenter.setLayout(new BorderLayout() );		
		GridLayout gridBoutons = new GridLayout(2,1,0,20);
		this.aCenter.setLayout( gridBoutons );
		this.aCenter.setBackground(this.aCOLOR_DARK_GREY);
			this.aTitle = new JLabel("Credit");
			this.aCredits = new JLabel("Jeux programm� sous Java \n"
								   + "Par Allan Bernier dans le cadre du projet de programmation\n"
								   + "du DUT informatique de Vannes.\n");
			this.aTitle.setForeground(new Color(255,255,255));
			this.aCredits.setForeground(new Color(255,255,255));

			
		this.aSouth = new JPanel();
			this.aBack = new Bouton("Retour", 900,40,this.aCOLOR_LIGHT_GREY);
	}
	
	protected  void add()
	{
		this.removeAll();
		this.add(this.aCenter, BorderLayout.CENTER);
			this.aCenter.add(this.aTitle);
			this.aCenter.add(this.aCredits);
		this.add(this.aSouth, BorderLayout.SOUTH);
			this.aSouth.add(aBack);
			
	}
	
	protected  void listeners()
	{
		aBack.addMouseListener( new java.awt.event.MouseAdapter()
		{
	         @Override
	         public void mouseReleased(java.awt.event.MouseEvent evt) 
	         {
	        	 aControleur.mCredits_Back();
	         }
		});
	}
}
