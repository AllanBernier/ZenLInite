package newProject;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log 
{
	
	public Log(String pMessage)
	{
		try
		{
			 DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			 Date date = new Date();
			 FileWriter fw = new FileWriter("Log.txt",true);
			 fw.write(format.format(date) + ": " + pMessage + "\n");
			 fw.close();		

		}
		catch (IOException e)
		{
		 //Gestion des exceptions en cas de probl�me d'acc�s au fichier
		}
	}
}
