package newProject;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Vue extends JFrame{

	private static final long serialVersionUID = -3608560151397303411L;
	
	public Vue(String pTitre)
	{
		super(pTitre);

		this.pack();
		this.setSize(900, 600);
		this.setVisible(true);
		mDrawMenu();
	}
	
	public void mDrawMenu()
	{
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout() );
		
		//Affichage du Titre du jeu
		JLabel title = new JLabel("Zen L'initie");
		menu.add(title, BorderLayout.NORTH);

		// Grid Layout affichant les boutons au millieu du menu
		GridLayout gridMenu = new GridLayout(6,1,0,30);
		JPanel midButton = new JPanel();
		midButton.setLayout( gridMenu );
		
		JButton bPvP = new JButton("Joueur vs Joueur");
		JButton bPvE = new JButton("Joueur vs IA");
		JButton b2v2 = new JButton("2 Joueurs vs 2 Joueurs");
		JButton bSaves = new JButton("Sauvegardes");
		JButton bRules = new JButton("Regles");
		JButton bCredits = new JButton("Credits");
		
		bSaves.addActionListener( (event) -> mDrawSaves(0) );
		bRules.addActionListener( (event) -> mDrawRules(0,0) );
		
		midButton.add(bPvP);
		midButton.add(bPvE);
		midButton.add(b2v2);
		midButton.add(bSaves);
		midButton.add(bRules);
		midButton.add(bCredits);
		bPvE.setPreferredSize( new Dimension(150,30) );

		
		menu.add(midButton, BorderLayout.CENTER);
		
		// Affichage du bouton Quitter en bas a droite
		JPanel placeQuit = new JPanel();
		placeQuit.setLayout(new BorderLayout() );
		JButton bQuit = new JButton("Quitter");
		placeQuit.add(bQuit, BorderLayout.SOUTH);
		menu.add(placeQuit, BorderLayout.WEST);
		
		this.setContentPane(menu);
		this.repaint();
		this.revalidate();
	}

	
	public void mDrawRules(int pFrom, int pRule)
	{
		JPanel rules = new JPanel();
		rules.setLayout(new BorderLayout() );
		
		//Affichage du Nom de la regle
		JLabel noRule = new JLabel("RegleNo 1");
		rules.add(noRule, BorderLayout.NORTH);
		
		//Affichage de la regle
		JLabel rule = new JLabel("CECI EST LA REGLES NUMERO 1");
		rules.add(rule, BorderLayout.CENTER);
		
		//Affichage des boutons suivant, precedant et retour
		GridLayout gridButon = new GridLayout(1,3,10,0);
		JPanel panButton = new JPanel();
		panButton.setLayout( gridButon );
		
		
		JButton bPrevious = new JButton("Precedant");
		JButton bBack = new JButton("Retour");
		JButton bNext = new JButton("Suivant");
		
		bBack.addActionListener( (event) -> mDrawMenu() );
		
		
		panButton.add(bPrevious);
		panButton.add(bBack);
		panButton.add(bNext);
		
		rules.add(panButton, BorderLayout.SOUTH);
		
		
		this.setContentPane(rules);
		this.repaint();
		this.revalidate();
	}
	
	public void mDrawSaves(int pNoSave)
	{
		if (pNoSave >= 0 && pNoSave < 5)
		{
			JPanel saves = new JPanel();
			saves.setLayout(new BorderLayout() );
			

			
			JLabel infoSave = new JLabel("Sauvegarde Numero" + pNoSave);
			saves.add(infoSave, BorderLayout.NORTH);

			
			Load load = new Load(pNoSave);
			int[][] plateau = load.getPlateau();
			JPanel grid = new JPanel();
			grid.setLayout( new GridLayout(11,11) );
			
			for (int i = 0; i < 11; i ++)
			{			
				for (int j = 0; j < 11; j ++)
				{
					grid.add(new JLabel( "" + (plateau[i][j])  ) );
				}
			}
			
			
			saves.add(grid, BorderLayout.CENTER);
			
			//Affichage des boutons Continuer, supprimer et retour
			GridLayout gridButon = new GridLayout(2,3,10,0);
			JPanel panButton = new JPanel();
			panButton.setLayout( gridButon );
			
			JButton bDelete = new JButton("Supprimer");
			JButton bBack = new JButton("Retour");
			JButton bPlay = new JButton("Continuer");
			JButton bPrevious = new JButton("Precedent");
			JButton bNext = new JButton("Suivant");

			
			bDelete.addActionListener( (event) -> a( pNoSave)  );
			
			
			bPrevious.addActionListener( (event) -> mDrawSaves(pNoSave - 1) );
			bNext.addActionListener( (event) -> mDrawSaves(pNoSave + 1) );
			bBack.addActionListener( (event) -> mDrawMenu() );
			
			panButton.add(bDelete);
			panButton.add(bBack);
			panButton.add(bPlay);
			panButton.add(bPrevious);
			panButton.add(bNext);

			saves.add(panButton, BorderLayout.SOUTH);
			
			this.setContentPane(saves);
			this.repaint();
			this.revalidate();
		}
		else
		{
			new Log("mDrawSaves : probl�mes de parametre");
		}
	}
	
	public void a(int pNoSave)
	{
		new Save(pNoSave);
		mDrawSaves(pNoSave);
	}
	
}
