package newProject;

public class PlayerIA extends Player {
	
	public PlayerIA(int pColor)
	{
		super(pColor);
	}

	int play(Zen pZen, int[][] pPlateau, int aNoTurn, int aMode) {
		return 0;
	}
}
