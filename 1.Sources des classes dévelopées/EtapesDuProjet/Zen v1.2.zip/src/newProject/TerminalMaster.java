package newProject;

import java.util.Scanner;


public class TerminalMaster {
	Scanner sc;			// Interaction uttilisateur 

	Player aWhite;
	Player aBlack;
	
	Player aWhiteBis; // Au cas ou le mode est 2x2
	Player aBlackBis;
	
	Player aCurrent;
	
	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu
	int aMode;
	
	TerminalUtile aUtile;
	
	
	/**
	 * Initialise le Scanner pour les entree clavier
	 * Instencie un TerminalUtile.
	 */
	public TerminalMaster()
	{
		this.sc = new Scanner(System.in);
		aUtile = new TerminalUtile();
	}

	
	/**
	 * Initialise les attribut d'une partie en fonction du mode 
	 * @param pMode le mode de jeux avec 1/Joue en Player vs IA, 2/ Joue en Player vs Player 3/ Joue en 2 Player vs 2 Player
	 * 
	 */
	public void mNewGame(int pMode)
	{
		switch(pMode)
        {
	        case 1: //Joue en Player vs IA
	        	aWhite = new PlayerHumanTerminal(1);
	        	aBlack = new PlayerIATerminal(-1);
	        break;
	        case 2: //Joue en Player vs Player
	        	aWhite = new PlayerHumanTerminal(1);
	        	aBlack = new PlayerHumanTerminal(-1);

	        break;
	        case 3: // Joue en 2 Player vs 2 Player

	        	aWhite = new PlayerHumanTerminal(1);
	        	aBlack = new PlayerHumanTerminal(-1);

	        	aWhiteBis = new PlayerHumanTerminal(1);
	        	aBlackBis = new PlayerHumanTerminal(-1);
	        break;
        }
		this.aCurrent = mChoiceColor();		
		this.aPlateau = this.aUtile.mInitPlateau();
		this.aZen = new Zen();
		this.aNoTurn = 0;
	}
	
	/**
	 *	Demande au joueur de choisir une couleur entre eux entre noir et blanc 
	 *	Math.random leurs d�signe quel joueur commence 
	 * @return l'indice du joueur qui commence entre -1 et 1 avec -1 pour noir et 1 pour blanc
	 */
	public Player mChoiceColor()
	{
		System.out.println("Choissez entre vous qui est le joueur Blanc et qui est le joueur noir ");
		System.out.println("appuyer sur [entrer] ");
		sc.nextLine();				
		
		System.out.println("1...");
		System.out.println("2...");
		System.out.println("3...");
        
		
		Player playerStart = null;
		int start = (int)(Math.random() * 2) + 1; 
        
        if (start == 1 )
        {
       	System.out.println("Blanc commence !");
       	playerStart = this.aWhite;
        }
        else
        {
    		System.out.println("Noir commence !");
    		playerStart = this.aBlack;
        }
        
		System.out.println("appuyer sur [entrer] ");
		sc.nextLine();
		
		return playerStart;
	}
	
	
	/**
	 * Lance le menu puis  en retour lance une fenetre comprise entre 1 et 6 corespondant aux differentes fenetre possible a afficher
	 */
	public void mMenu()
	{

		
		int choix = -1;
		do 
		{
			System.out.println("1: Player Vs IA (pas fait)");
			System.out.println("2: Player vs Player");
			System.out.println("3: 2 Player Vs 2 Player (pas fait)");
			System.out.println("4: Regles");
			System.out.println("5: Sauvegardes");
			System.out.println("6: Quitter");
			System.out.println("7: Credits ");
			
			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e)
			{
				new Log("mMenu : tryCatch - NumberFormatException");
			}				
		}while ( choix <= 0 || choix > 7);
		
		mRunMenu( choix , 8); // Lance le menu correspondant (8 etant le menu
	}
	
	/**
	 * Lance les differents elements graphique que le joueur voudrais afficher
	 * @param pFrame Le menu a lancer
	 * @param pFrom	Le lieux d'appel de la fonction
	 */
	public void mRunMenu(int pFrame, int pFrom)
	{
		if (pFrame > 0 && pFrame <= 8)
		{
			switch(pFrame)
	        {
	            case 1:
	        		new Log("Joue en Player vs IA");
	        		System.out.println("== Player Vs IA == ");
	        		mNewGame(1);
	        		mMenu();
	            break;
	            
	            case 2:
	        		new Log("Joue en Player vs Player");
	        		System.out.println("== Player vs Player == ");
	        		mNewGame(2);
	        		mStart();
	            break;
	            
	            case 3:
	        		new Log("Joue en 2 Player vs 2 Player");
	        		System.out.println("== 2 Player Vs 2 Player == ");
	        		mNewGame(3);
	        		mMenu();
	        	break;
	        	
	            case 4:
	        		new Log("Ouverture du menu Regles");
	        		System.out.println("== Regles == ");
	        		aUtile.mRules();
	            break;
	            
	            case 5:
	        		new Log("Ouverture du menu Sauvegardes");
	        		System.out.println("== Sauvegardes == ");
	        		mSaves();
	            break;
	            
	            case 6:
	        		new Log("Fin du jeux : le programme s'est termin� sans probl�mes");
	        		System.out.println("== Quitter == ");
					System.exit(0); 
	            break;
	            
	            case 7:
	        		new Log("Ouverture du menu Credits");
	        		System.out.println("== Credits == ");
	        		aUtile.mCredits();
	            break;
	        }
		}
	}
	
	/**
	 * Lance une partie (en player vs player) 
	 * fait jouer chaqu'un des joueur present dans la partie chaqu'un leur tour en appelant
	 * la methode play de player puis appel la methode newTurn() pour changer de tour de jeu.
	 */
	public void mStart()
	{
		int act; //Si act == - 1 alors, quitter la partie puis retourne au menu
		GameOver gameOver;
		//int winer;
		do
		{	
			act = this.aCurrent.play(aZen, this.aPlateau, this.aNoTurn, this.aMode);
			newTurn();		
			
			gameOver = new GameOver(aCurrent.getColor() , this.aZen, this.aPlateau);
		}while( gameOver.mIsOver() != true && act != -2 );
	}

	/**
	 * Initialise un nouveau tour,
	 * Augmente le numero de tour de 1,
	 * Recupere les valeur changer par le joueur courrant tel que le Zen et le Plateau
	 * Change le joueur courant avec le joueur qui dois jouer.
	 */
	public void newTurn()
	{
		// Le tour de jeu augente de 1
		this.aNoTurn ++;

		
		// On change de joueur courant, puis, on redemande les info que le joueur a changer
		if ( this.aCurrent == this.aBlack)
		{
			this.aPlateau = this.aBlack.getPlateau();
			this.aZen = this.aBlack.getZen();
			this.aCurrent = this.aWhite;
		}
		else if (this.aCurrent == this.aWhite)
		{
			this.aPlateau = this.aWhite.getPlateau();
			this.aZen = this.aWhite.getZen();
			this.aCurrent = this.aBlack;
		}
		
	}
	
	/** 
	 * Cette methode fonctionne de la m�me facon que mRules,
	 * Elle affiche la sauvegarde � l'indice i et le joueur peut choisir:
	 * De continuer la partie
	 * De supprimer la sauvegarde
	 * De retourner au menu
	 * De voir la sauvegarde suivante
	 * De voir la sauvegarde precedante
	 */
	public void mSaves()
	{
		
		String[] save = new String[5];

		
		
		int actualSave = 0;
		int choix = -1;

		do 
		{
			// Si le joueur clique sur soivant ou precedant on change l'indice
			if (choix == 1) 
			{
				actualSave --;
			}
			else if ( choix == 3)
			{
				actualSave ++;
			}
			
			// Si l'indice d�passe le nombre de sauvegarde ou est inf�rieur a 0 alors on l'inverse
			if (actualSave >= save.length )
			{
				actualSave = 0; 
			}
			else if (actualSave < 0)
			{
				actualSave = save.length - 1 ; 
			}
			
			save[actualSave] = mSaveToString(actualSave);

			System.out.println("Sauvegarde no:" + actualSave + "\n" + save[actualSave] + "\n\n" + " 1: Precedent \t 2: Retour \t 3: Suivant \t 4: supprimer \t 5: continuer");

			// Si le joueur ne rentre pas un nombre, on evite de crash.
			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e){
				new Log("mSaves : tryCatch - NumberFormatException");
			} 
			
		}while ( choix != 2 && choix != 5); // Si le joueur veux faire retour OU jouer la sauvegarde, alors on sort de la boucle
				
		// Si le choix est egale a 2, la fonction s'arette et retourne a son lieux d'appel	
		
		// Si le choix est egale a 5, on charge la partie
		if (choix == 5)
		{
			loadGame(actualSave);
		}
	}

	/**
	 * Charge une sauvegarde grace a la classe Load puis transforme cette sauvegarde en un apercu du cour de la partie 
	 * @param pSave l'indice de la sauvegarde
	 * @return Apercu de la partie
	 */
	public String mSaveToString(int pSave)
	{
		System.out.println("La save " + pSave);
		Load loadGame = new Load(pSave);
		int[][] plateau = loadGame.getPlateau();
		String ret = "";
		
		// transforme le plateau en un block de caractere de 11 lignes par 11 colonnes 
		for (int l = 0 ; l< plateau.length ; l++)
		{
			for (int c = 0 ; c < plateau[l].length ; c++)
			{
				if (plateau[l][c] == -1 )
				{
					ret = ret + "3  ";
				}
				else
				{
					ret = ret + plateau[l][c] + "  ";
				}
			}	
			ret = ret + "\n";
		}
		
		ret = ret + "\n" + loadGame.toString();
		return ret;
	}

	/**
	 * Charge tout les attribut de cette classe grace a la sauvegarde a l'indice actualSave puis lance la partie.
	 * @param pSave, l'indice de sauvegarde
	 */
	public void loadGame(int pSave)
	{
		new Log("Le joueur a charger la sauvegarde n�" + pSave);
		Load game = new Load(pSave);

		this.aZen = game.getZen();			// instance de Zen contenant toutes les information utile sur lui 
		this.aPlateau = game.getPlateau(); 	// Avanc� du plateau de jeu
		this.aNoTurn = game.getNoTurn(); 		// Numero du tour de jeu
		int turnToPlay = game.getNextPlayer(); 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
		this.aMode = game.getMode();
		
		
		switch(this.aMode)
        {
	        case 1: //Joue en Player vs IA
	        	aWhite = new PlayerHumanTerminal(1);
	        	aBlack = new PlayerIATerminal(-1);
	        break;
	        case 2: //Joue en Player vs Player
	        	aWhite = new PlayerHumanTerminal(1);
	        	aBlack = new PlayerHumanTerminal(-1);

	        break;
	        case 3: // Joue en 2 Player vs 2 Player

	        	aWhite = new PlayerHumanTerminal(1);
	        	aBlack = new PlayerHumanTerminal(-1);

	        	aWhiteBis = new PlayerHumanTerminal(1);
	        	aBlackBis = new PlayerHumanTerminal(-1);
	        break;
        }
		
		if ( turnToPlay == 1 )
		{
			this.aCurrent = this.aWhite;
		}
		else
		{
			this.aCurrent = this.aBlack;
		}
		
		mStart();
		
	}
	
	

}
