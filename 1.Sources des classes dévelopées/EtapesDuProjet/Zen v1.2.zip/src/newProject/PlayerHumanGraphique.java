package newProject;

public class PlayerHumanGraphique extends PlayerHuman{

	public PlayerHumanGraphique(int pColor)
	{
		super(pColor);
	}

	int play(Zen pZen, int[][] pPlateau, int aNoTurn, int aMode) {
		return 0;
	}
}
