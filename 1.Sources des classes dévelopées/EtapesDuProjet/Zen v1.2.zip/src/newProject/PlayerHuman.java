package newProject;

abstract class PlayerHuman extends Player{
	
	public PlayerHuman(int pColor)
	{
		super(pColor);
	}

	abstract int play(Zen pZen, int[][] pPlateau,int aNoTurn, int aMode);
}
