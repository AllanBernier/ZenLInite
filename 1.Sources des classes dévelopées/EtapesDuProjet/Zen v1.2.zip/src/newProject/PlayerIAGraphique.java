package newProject;

public class PlayerIAGraphique {

	public PlayerIAGraphique(int pColor)
	{
		super();
	}
}
