package newProject;

public class PlayerIATerminal extends PlayerIA {

	public PlayerIATerminal(int pColor)
	{
		super(pColor);
	}
}
