package newProject;

public class PlayerIATerminal extends PlayerIA {

	public PlayerIATerminal(int pColor)
	{
		super(pColor);
	}

	@Override
	protected boolean mEndTurn() {
		// TODO Auto-generated method stub
		return false;
	}
}
