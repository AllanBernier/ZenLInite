package newProject;

public enum Color {
	  WHITE, 
	  BLACK, 
	  ZEN  
}
