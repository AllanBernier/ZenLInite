package newProject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Save {

	int[][] aPlateau;	
	int aMode;
	Zen aZen;
	int aNextPlayer;
	int aNoTurn;
	
	/**
	 * Convertie tout les parametre en un string puis les enregistre dans un fichier texte a l'indice pSave
	 * 
	 * @param pPlateau
	 * @param pMode
	 * @param pZen
	 * @param pNextPlayer
	 * @param pNoTurn
	 * @param pSave
	 */
	public Save(int[][] pPlateau, int pMode, Zen pZen, int pNextPlayer, int pNoTurn, int pSave) 
	{
		if ( pPlateau != null && pZen != null && pSave >= 0 && pSave < 5)
		{
			this.aMode = pMode;
			this.aNextPlayer = pNextPlayer;
			this.aPlateau = pPlateau;
			this.aNoTurn = pNoTurn;
			this.aZen = pZen;
			SaveGame(pSave);
		}
		else 
		{
			System.out.println("parametre null");
		}
	}
	public Save(int pSave)
	{
		this.aMode = 1;
		this.aNextPlayer = 1;
		int[][] plateau = {
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0,0,0,0,0}
		};
		this.aPlateau = plateau;
		this.aNoTurn = 0;
		this.aZen = new Zen();
		SaveGame(pSave);

	}
	
	
	/**
	 * Supprime la sauvegarde existante a l'incice pSave et le remplace par une partie au tour 1
	 * @param pSave l'indice de la sauvegarde.
	 */
	private void SaveGame(int pSave) 
	{

		
		String zen = mZenToString();
		String turn = mSaveTurnToString();
		String plateau = mPlateauToString();
		
		File txt =  new File("Save_" + pSave + ".txt");
		try {
			txt.createNewFile();
			
			FileWriter txtWrite = new FileWriter(txt);
			txtWrite.write( zen );
			txtWrite.write( turn );
			txtWrite.write( plateau );
	
			txtWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Convertie chaque element du Zen un seul et unique string
	 * la chaine est de la forme ligne:colonne:oldLigne:oldColonne:noTurn:isAlive;
	 * 6:6:6:6:0:true;
	 * toutes les valeur sont des int sauf le isAlive qui est un boolean
	 * La chaine termine par un point virgule
	 * @return zen transformer en string
	 */
	private String mZenToString()
	{
		int l = this.aZen.getLine();
		int c = this.aZen.getColumn();
		int oldL = this.aZen.getLastLine();
		int oldC = this.aZen.getLastColumn();
		int noT = this.aZen.getNoTurn();
		boolean alive = this.aZen.getIsAlive();
		
		String zenStr =  l + ":" + c + ":" + oldL + ":" + oldC + ":" + noT + ":" + alive + ";";
		
		return zenStr;
	}
	
	
	/**
	 * Convertie l'attribut plateau en string
	 * chaque ligne est delimiter par une , chaque valeur est delimiter par : chaque valeur fait 2 caractere
	 *  "-1" , "1 " ou "2 "
	 * La fin du tableau se termine par un point virgule
	 * 0 :0 :0 :-1:0 :-1:0 :0 :0 :0 :,0 :0 :1 :0 :0 :0 :1 :0 :0 :..ect..:0 :0 :0 :1 :;
	 * @return plateau transformer en string 
	 */
	private String mPlateauToString()
	{
		String zenStr = "";

		for (int l = 0; l < this.aPlateau.length; l++ )
		{
			for (int c = 0; c < this.aPlateau[l].length; c++ )
			{
				if ( this.aPlateau[l][c] == -1 )
				{
					zenStr = zenStr + this.aPlateau[l][c] + ":";
				}
				else
				{
					zenStr = zenStr + this.aPlateau[l][c] + " :";
				}
					
			}
			if (l < this.aPlateau.length - 1)
			{
				zenStr += ",";
			}
		}
		
		zenStr = zenStr + ";";
		
		
		return zenStr;

	}
	/**
	 * Convertie l'attribut mode de la partie, numero du tour de jeu et indice de prochain joueur a jouer
	 * forme aMode:aNoTurn:aNextPlayer;
	 * 2:18:-1;

	 * separateur : et ;
	 * @return les attribut transformer en string
	 */
	private String mSaveTurnToString()
	{
		
		String str = this.aMode + ":"  + this.aNoTurn + ":" + this.aNextPlayer + ";";
		return str;	
		
	}
	
}
