package newProject;

public class PlayerHumanGraphique {

	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu
	
	boolean aPionSelected;
	boolean aEndTurn;
	int[] aPion;
	int[] aWhere;
	int aColor;

	int aTurnToPlay; 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
		

	
	public PlayerHumanGraphique(int pColor, Zen pZen)
	{
		
		this.aPionSelected = false;
		this.aEndTurn = false;
		this.aColor = pColor;
		this.aZen = pZen;
		this.aPion = new int[2];
		this.aWhere = new int[2];
	}

	/**
	 * Recoit un ligne et une colonne et remplie les tableau aPion et aWhere en fonction de l'avancement du tour
	 * @param pZen
	 * @param pPlateau
	 * @param aNoTurn
	 * @param aMode
	 * @param pLine
	 * @param pColumn
	 * @return
	 */
	public void play(Zen pZen, int[][] pPlateau, int pNoTurn, int pLine, int pColumn) {
		this.aPlateau = pPlateau;
		this.aZen = pZen;
		this.aNoTurn = pNoTurn;
		
		if ( !this.aPionSelected ) // Si on a pas selectionner de pion
		{
			// Si le pion cliquer est un de mes pions (ou zen)
			if ( this.aPlateau[pLine][pColumn] == this.aColor || this.aPlateau[pLine][pColumn] == this.aZen.getZenColor() )
			{
				// Alors aPionSelected est vrais et le tableau a pion est  remplis 
				this.aPionSelected = true;
				this.aPion[0] = pLine;
				this.aPion[1] = pColumn;
			}
			
		}
		else
		{
			int[][] move = new  Move( this.aPlateau ,this.aPion[0]  , this.aPion[1] , this.aColor ).getMove();
			
			if( this.aPlateau[ this.aPion[0] ][ this.aPion[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
			{
				move = this.aZen.mZenMove(this.aPlateau, move , this.aNoTurn);
			}
			
			int index = mBelongsToTab(move,  pLine,  pColumn);

			if (index != -1 && ( move[index][2] == 1 || move[index][2] == 3) )
			{
				this.aWhere = move[index];
				this.aEndTurn = true;
			}
			else
			{
				this.aPionSelected = false;
			}
		}
		
		//mToString();
	}
	
	
			
	/**
	 * Verifit que la position envoyer en parametre appartient au tableau de deplacement.
	 * @param pMove le tableau de position
	 * @param pLine la ligne
	 * @param pColumn la colonne
	 * @return renvoie l'index au quel est la position dans le tableau, -1 si cette position n'est pas dans le tableau.
	 */
	private int mBelongsToTab(int[][] pMove, int pLine, int pColumn)
	{
		int ret = -1;
		for (int i = 0; i < pMove.length; i++)
		{
			if ( pMove[i][0] == pLine && pMove[i][1] == pColumn )
			{
				ret = i;
			}
		}
		
		return ret;
	}
	

	public int[] getPion()
	{
		return this.aPion;
	}
	
	public int[] getWhere()
	{
		return this.aWhere;
	}
	
	public boolean getEndTurn() {
		return this.aEndTurn;
	}

	public int getColor()
	{
		return this.aColor;
	}
	
	public boolean getSelected()
	{
		return this.aPionSelected;
	}
	
	public void setNewTurn()
	{
		this.aEndTurn = false;
		this.aPionSelected = false;
	}
	
	public void setNoTurn(int pNoTurn)
	{
		this.aNoTurn = pNoTurn;
	}
	
	public void mToString()
	{
		System.out.println("==PlayerHumanGraphique==");
		System.out.println("aPionSelected: " + this.aPionSelected );
		System.out.println("aEndTurn: " + this.aEndTurn );
		System.out.println("aPion: " + this.aPion[0] + "  " +  this.aPion[1] );
		System.out.println("aWhere: " + this.aWhere[0] + "  " +  this.aWhere[1] );
		System.out.println("aColor: " + this.aColor );
		System.out.println("========================" );
	}
	
}






