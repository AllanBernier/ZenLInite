package newProject;

public class Game {
	
	Vue aVue; // Graphique

	PlayerHumanGraphique aWhite;
	PlayerHumanGraphique aBlack;
	
	PlayerHumanGraphique aCurrent;
	
	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu
	int aMode;
	
	/**
	 * Dans le cas ou je commence un nouvelle partie, utiliser ce constructeur
	 * @param pVue le graphique 
	 * @param pMode le mode de jeu
	 */
	public Game(Vue pVue,int pMode)
	{
		this.aVue = pVue;
		mNewGame(pMode);
	}
	
	
	
	
	/**
	 * Initialise les attribut d'une partie en fonction du mode 
	 * @param pMode le mode de jeux avec 1/Joue en Player vs IA, 2/ Joue en Player vs Player 3/ Joue en 2 Player vs 2 Player
	 * 
	 */
	public void mNewGame(int pMode)
	{
		this.aPlateau = mInitPlateau();
		this.aZen = new Zen();
		this.aNoTurn = 0;
		switch(pMode)
        {
	        case 1: //Joue en Player vs IA
	        	aWhite = new PlayerHumanGraphique(1, aZen);
	        	aBlack = new PlayerHumanGraphique(-1, aZen);
	        break;
	        case 2: //Joue en Player vs Player
	        	aWhite = new PlayerHumanGraphique(1, aZen);
	        	aBlack = new PlayerHumanGraphique(-1, aZen);

	        break;
	        case 3: // Joue en 2 Player vs 2 Player

	        	aWhite = new PlayerHumanGraphique(1, aZen);
	        	aBlack = new PlayerHumanGraphique(-1, aZen);

	        break;
        }
		this.aCurrent = aWhite;	
		this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);

	}
	
	public int[][] mInitPlateau()
	{
		int ret[][] =  {{1 ,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,-1},//0
						{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//1
						{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//2
						{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//3
						{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//4
						{-1,0 ,0 ,0 ,0 ,2 ,0 ,0 ,0 ,0 ,-1},//5
						{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//6
						{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//7 c 3 l 8
						{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//8
						{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//9
						{-1,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,1 } //10
					}; //0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10	
		return ret;
		
	}
	
	public void mCaseClicked(int pLine ,int pColumn)
	{
		new Log("La case cliqu� est la : [" + pLine + "][" + pColumn + "]");

		aCurrent.play(aZen, aPlateau,this.aNoTurn, pLine, pColumn);
		
		if (this.aCurrent.getSelected() )
		{
			
			int[] pion = aCurrent.getPion();

			if ( !this.aCurrent.getEndTurn() )
			{
				
				int[][] move = new  Move( this.aPlateau , pion[0] , pion[1] , this.aCurrent.getColor() ).getMove();
				
				if( this.aPlateau[ pion[0] ][ pion[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
				{
					move = this.aZen.mZenMove( this.aPlateau , move , this.aNoTurn);
				}
				
				this.aVue.mDrawGame( PlateauToString( this.aPlateau, move, pion  ), 0, 0, true);
			}
			else 
			{
				
				int[] where = aCurrent.getWhere();
				
				
				
				this.aPlateau[ where[0] ][ where[1] ] = this.aPlateau[ pion[0] ][ pion[1] ]; // On bouge le pion 
				this.aPlateau[ pion[0] ][ pion[1] ] = 0; // L'ancienne case du pion est vide.
				this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
				
				if( this.aPlateau[ where[0] ][ where[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
				{
					System.out.println("========== "+ where[0] + " ===== "+ where[1] + " ==========="+ pion[0] + " ===== "+ pion[1] + "===========");
					this.aZen.mRefreshZen(where[0], where[1], this.aNoTurn );
				}
				
				new Log("Deplacement du pion " + ( (this.aCurrent.getColor() == 1) ? "Blanc" : "Noir") + " de la case [" + pion[0] + "][" + pion[1] + "] � [" + where[0] + "][" + where[1] + "]" );
				this.aCurrent.setNewTurn();
				newTurn();
			}
		}
		else
		{
			this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
		}
		
		
	
	}
	
	/**
	 * Initialise un nouveau tour,
	 * Augmente le numero de tour de 1,
	 * Recupere les valeur changer par le joueur courrant tel que le Zen et le Plateau
	 * Change le joueur courant avec le joueur qui dois jouer.
	 */
	public void newTurn()
	{
		// Le tour de jeu augente de 1
		this.aNoTurn ++;
		this.aBlack.setNoTurn(this.aNoTurn);
		this.aWhite.setNoTurn(this.aNoTurn);
		
		// On change de joueur courant, puis, on redemande les info que le joueur a changer
		if ( this.aCurrent == this.aBlack)
		{
			//this.aPlateau = this.aBlack.getPlateau();
			//this.aZen = this.aBlack.getZen();
			this.aCurrent = this.aWhite;
			new Log("Au tour du joueur Blanc");
		}
		else if (this.aCurrent == this.aWhite)
		{
			
			//this.aPlateau = this.aWhite.getPlateau();
			//this.aZen = this.aWhite.getZen();
			this.aCurrent = this.aBlack;
			new Log("Au tour du joueur Noir");

		}
		
	}

	public String[][] PlateauToString(int[][] pPlateau)
	{
		String[][] myTab = new String[11][11];
		
		for (int l = 0; l < pPlateau.length; l++)
		{
			for (int c = 0; c < pPlateau.length; c++)
			{
				if (pPlateau[l][c] == 0 )
				{
					myTab[l][c] = "";
				}
				else if (pPlateau[l][c] == 1 )
				{
					myTab[l][c] = "Blanc";
				}
				else if (pPlateau[l][c] == -1 )
				{
					myTab[l][c] = "Noir";
				}
				else if (pPlateau[l][c] == 2 )
				{
					myTab[l][c] = "Zen";
				}
			}			
		}
		return myTab;
	}
	
	public String[][] PlateauToString(int[][] pPlateau, int[][] pDeplacements,int[] pPosPion)
	{
		String[][] myTab = new String[11][11];
		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{				
				if( pPlateau[l][c] == -1) // Noir
				{
					myTab[l][c] = "Noir";
				}
				else if( pPlateau[l][c] == 0) // Case vide
				{
					myTab[l][c] = "";
				}
				else if( pPlateau[l][c] == 1 ) // Blanc
				{
					myTab[l][c] = "Blanc";
				}
				else if (pPlateau[l][c] == 2) // Zen l'initi�
				{
					myTab[l][c] = " Zen";
				}
				
			}
		}
		
		myTab[ pPosPion[0] ][ pPosPion[1] ] = "[" + myTab[ pPosPion[0] ][ pPosPion[1] ] + "]";

		
		for (int i = 0; i < 8 ; i++)
		{
			if (pDeplacements[i][2] == 1)
			{
				myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "[[" + myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] + "]]";
			}
			else if( pDeplacements[i][2] == 3 )
			{
				myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "{{eat}}";
			}
		}
		
		return myTab;
	}

	public void mRulesBack()
	{
		if (this.aCurrent.getSelected() )
		{
			int[] pion = aCurrent.getPion();
			int[][] move = new  Move( this.aPlateau , pion[0] , pion[1] , this.aCurrent.getColor() ).getMove();
			
			if( this.aPlateau[ pion[0] ][ pion[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
			{
				move = this.aZen.mZenMove( this.aPlateau , move , this.aNoTurn);
			}	
			this.aVue.mDrawGame( PlateauToString( this.aPlateau, move, pion  ), 0, 0, true);
		}
		else
		{
			this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
		}
		
		
	}
	
}
