package newProject;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class frame extends JFrame{
	JPanel pan;
	
	public frame()
	{
		super("Zen");
		this.setLayout(new FlowLayout() );
		this.pan = new JPanel();
		this.pan.setLayout(new BorderLayout() );
		
		
		
		
		
		this.pan.add( new JLabel("Zen l'initie"), BorderLayout.NORTH);
		JPanel fenetre1 = new JPanel();
		fenetre1.setLayout( new GridLayout(11,11) );
		
		for (int i = 0; i < 11; i ++)
		{			
			for (int j = 0; j < 11; j ++)
			{
				fenetre1.add(new JButton(i + " " + j));
			}
		}
		
		JButton b1 = new JButton("texte");
		
		b1.addActionListener( (event) -> newFrame() ); 
		
		
		JPanel p1 = new JPanel();
		p1.setLayout(new BorderLayout() );
		
		p1.add(b1, BorderLayout.SOUTH);
		
		this.pan.add(p1, BorderLayout.EAST);
		
		
		
		
		this.pan.add(fenetre1);
		
		this.pack();
		this.setSize(900, 600);
		this.setVisible(true);
		this.setContentPane(this.pan);
	
	}

	public void newFrame()
	{
		System.out.println("a");
		JPanel fenetre2 = new JPanel();
		fenetre2.setLayout(new FlowLayout());
		
		JButton b1 = new JButton("Click me");
		b1.addActionListener( (event) -> newFrame2());
		fenetre2.add(b1);
		
		//this.pan = fenetre2;
		this.setContentPane(fenetre2);
		this.repaint();
		this.revalidate();
	}
	
	public void newFrame2()
	{
		System.out.println("a");
		JPanel fenetre2 = new JPanel();
		fenetre2.setLayout(new FlowLayout());
		
		JButton b1 = new JButton("Click ");
		b1.addActionListener( (event) -> newFrame());

		fenetre2.add(b1);
		
		//this.pan = fenetre2;
		this.setContentPane(fenetre2);
		this.repaint();
		this.revalidate();
	}
}
