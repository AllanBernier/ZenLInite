package newProject;

public enum Mode {
	  PvP,
	  PvIA,
	  PvP4Joueurs;	
}
