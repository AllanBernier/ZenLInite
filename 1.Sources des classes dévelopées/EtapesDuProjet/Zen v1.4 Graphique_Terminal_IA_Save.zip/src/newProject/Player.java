package newProject;

import java.util.Scanner;

abstract class Player {
	
	int aColor;
	Scanner sc = new Scanner(System.in);
	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu
	int aTurnToPlay; 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
	
	public Player(int pColor)
	{
		this.aColor = pColor;
	}
	
	public int getColor()
	{
		return this.aColor;
	}

		
	public int[][]	getPlateau()
	{
		return this.aPlateau;
	}
	
	public Zen getZen()
	{
		return this.aZen;
	}
	
	
	abstract int play(Zen pZen, int[][] pPlateau,int aNoTurn, Mode pMode);

	protected abstract boolean mEndTurn();

}


 