package newProject;


/**
 * Dans ce projet:
 * L'ensemble des attribut commencent par un a
 * 
 * 
 * L'ensemble des methodes comment par m a l'exception des getter et setter d'attribut commencent 
 * respectivement par get et set suivi du nom de l'attribut (sans le a)
 * 
 * L'ensemble des parametre commencent par un p
 * Les variables definis au seins d'une methode n'ont pas de regles particulieres
 * 
 * Cette classe sert de lanceur entre le mode graphique et le mode terminal
 * @author Bernier Allan
 * @since 18/04/20
 */
public class MainProject 
{
	public static void main(String[] args)
	{
	//	new Log("Debut du programme.");
		new Vue("Zen");
	//
		TerminalMaster game = new TerminalMaster();
		while (true)
			game.mMenu();
		//new Log("Fin du programme.");
	
		/*
		Zen zen = new Zen();
		PlayerIAGraphique player = new PlayerIAGraphique(1, zen);
		int plateau[][] =  {{1 ,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,-1},//0
							{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//1
							{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//2
							{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//3
							{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//4
							{-1,0 ,0 ,0 ,0 ,2 ,0 ,0 ,0 ,0 ,-1},//5
							{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//6
							{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//7 c 3 l 8
							{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//8
							{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//9
							{-1,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,1 } //10
						}; //0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10	
		int noTurn = 0;
		Scanner sc = new Scanner(System.in);
		while( true)
		{
			sc.nextLine();

		*/
	}
}
