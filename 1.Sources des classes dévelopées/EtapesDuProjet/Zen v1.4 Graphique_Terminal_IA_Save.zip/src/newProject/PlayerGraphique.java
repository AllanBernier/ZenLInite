package newProject;

import file.Log;

public class PlayerGraphique implements IPlayable{

	protected Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	protected int[][] aPlateau; 	// Avanc� du plateau de jeu
	protected int aNoTurn; 		// Numero du tour de jeu
	
	protected boolean aPionSelected;
	protected boolean aEndTurn;
	protected int[] aPion;
	protected int[] aWhere;
	protected int aColor;

	int aTurnToPlay; 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
	
	
	
	public PlayerGraphique(int pColor, Zen pZen)
	{
		
		this.aPionSelected = false;
		this.aEndTurn = false;
		this.aColor = pColor;
		this.aZen = pZen;
		this.aPion = new int[2];
		this.aWhere = new int[2];
	}



	public void mPlay(Zen pZen, int[][] pPlateau, int pNoTurn) {
		Log.mLog("Error : M�thode mPlay utiliser dans PlayerGraphique");
	} // Red�finis dans ses classe filles




	public void isClicked(int pLine, int pColumn) {
		
	}




	public boolean getSelected() {
		return this.aPionSelected;
	}




	public int[] getPion() {
		return this.aPion;
	}

	public boolean getEndTurn() {
		return this.aEndTurn;
	}




	public int getColor() {
		return this.aColor;
	}




	public int[] getWhere() {
		return this.aWhere;
	}




	public void setNewTurn() {
		this.aEndTurn = false;
		this.aPionSelected = false;		
	}




	public void setNoTurn(int pNoTurn) {
		this.aNoTurn = pNoTurn;		
	}
	
	
	
}
