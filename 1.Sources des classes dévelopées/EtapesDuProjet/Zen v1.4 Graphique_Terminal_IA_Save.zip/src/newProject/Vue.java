package newProject;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import file.Load;
import file.Log;
import file.Save;

public class Vue extends JFrame{
	Game aControleur; 

	private static final long serialVersionUID = -3608560151397303411L;
	
	public Vue(String pTitre)
	{
		super(pTitre);
		this.getDefaultCloseOperation();
		this.pack();
		this.setSize(1200, 600);
		this.setVisible(true);
		this.aControleur = new Game(this);
		mDrawMenu();
	}
	
	public void mDrawMenu()
	{
		JPanel menu = new JPanel();
		menu.setLayout(new BorderLayout() );
		
		//Affichage du Titre du jeu
		JLabel title = new JLabel("Zen L'initie");
		menu.add(title, BorderLayout.NORTH);

		// Grid Layout affichant les boutons au millieu du menu
		GridLayout gridMenu = new GridLayout(6,1,0,30);
		JPanel midButton = new JPanel();
		midButton.setLayout( gridMenu );
		
		JButton bPvP = new JButton("Joueur vs Joueur");
		JButton bPvIA = new JButton("Joueur vs IA");
		JButton bIAvIA = new JButton("IA vs IA");
		JButton bSaves = new JButton("Sauvegardes");
		JButton bRules = new JButton("Regles");
		JButton bCredits = new JButton("Credits");
		
		bSaves.addActionListener( (event) -> mDrawSaves(0) );
		bRules.addActionListener( (event) -> mDrawRules(0,0, null) );
		bPvP.addActionListener( (event) -> this.aControleur.mNewGame(Mode.PvP) );
		bPvIA.addActionListener( (event) -> this.aControleur.mNewGame(Mode.PvIA) );
		bIAvIA.addActionListener( (event) -> this.aControleur.mNewGame(Mode.PvP4Joueurs) );
		bCredits.addActionListener( (event) -> mDrawCredits() );
		
		
		
		midButton.add(bPvP);
		midButton.add(bPvIA);
		midButton.add(bIAvIA);
		midButton.add(bSaves);
		midButton.add(bRules);
		midButton.add(bCredits);
		bPvIA.setPreferredSize( new Dimension(150,30) );

		
		menu.add(midButton, BorderLayout.CENTER);
		
		// Affichage du bouton Quitter en bas a droite
		JPanel placeQuit = new JPanel();
		placeQuit.setLayout(new BorderLayout() );
		JButton bQuit = new JButton("Quitter");
		placeQuit.add(bQuit, BorderLayout.SOUTH);
		menu.add(placeQuit, BorderLayout.WEST);
		
		this.setContentPane(menu);
		this.repaint();
		this.revalidate();
	}

	public void mDrawRules(int pFrom, int pRule, Game pGame)
	{
		JPanel rules = new JPanel();
		rules.setLayout(new BorderLayout() );
		
		//Affichage du Nom de la regle
		JLabel noRule = new JLabel("RegleNo 1");
		rules.add(noRule, BorderLayout.NORTH);
		
		//Affichage de la regle
		JLabel rule = new JLabel("CECI EST LA REGLES NUMERO 1");
		rules.add(rule, BorderLayout.CENTER);
		
		//Affichage des boutons suivant, precedant et retour
		GridLayout gridButon = new GridLayout(1,3,10,0);
		JPanel panButton = new JPanel();
		panButton.setLayout( gridButon );
		
		
		JButton bPrevious = new JButton("Precedant");
		JButton bBack = new JButton("Retour");
		JButton bNext = new JButton("Suivant");
		
		
		if (pFrom == 0 ) // Rules cliquer depuis le menu
		{
			bBack.addActionListener( (event) -> mDrawMenu() );
		}
		else// Rules cliquer depuis le jeu
		{
			bBack.addActionListener( (event) -> pGame.mRulesBack() );
		}
		
		
		panButton.add(bPrevious);
		panButton.add(bBack);
		panButton.add(bNext);
		
		rules.add(panButton, BorderLayout.SOUTH);
		
		
		this.setContentPane(rules);
		this.repaint();
		this.revalidate();
	}
	
	public void mDrawSaves(int pNoSave)
	{
		if (pNoSave >= 0 && pNoSave < 5)
		{
			JPanel saves = new JPanel();
			saves.setLayout(new BorderLayout() );
			

			
			JLabel infoSave = new JLabel("Sauvegarde Numero" + pNoSave);
			saves.add(infoSave, BorderLayout.NORTH);

			
			Load load = new Load(pNoSave);
			int[][] plateau = load.getPlateau();
			JPanel grid = new JPanel();
			grid.setLayout( new GridLayout(11,11) );
			
			for (int i = 0; i < 11; i ++)
			{			
				for (int j = 0; j < 11; j ++)
				{
					grid.add(new JLabel( "" + (plateau[i][j])  ) );
				}
			}
			
			
			saves.add(grid, BorderLayout.CENTER);
			
			//Affichage des boutons Continuer, supprimer et retour
			GridLayout gridButon = new GridLayout(2,3,10,0);
			JPanel panButton = new JPanel();
			panButton.setLayout( gridButon );
			
			JButton bDelete = new JButton("Supprimer");
			JButton bBack = new JButton("Retour");
			JButton bPlay = new JButton("Continuer");
			JButton bPrevious = new JButton("Precedent");
			JButton bNext = new JButton("Suivant");

			
			
			
			bPrevious.addActionListener( (event) -> mDrawSaves(pNoSave - 1) );
			bNext.addActionListener( (event) -> mDrawSaves(pNoSave + 1) );
			bBack.addActionListener( (event) -> mDrawMenu() );
			bDelete.addActionListener( (event) -> new Save(pNoSave) );
			bPlay.addActionListener( (event) -> this.aControleur.mNewGame(load.getMode(), load.getPlateau() , load.getZen(), load.getNoTurn(), load.getNextPlayer())  );

			
			
			
			panButton.add(bDelete);
			panButton.add(bBack);
			panButton.add(bPlay);
			panButton.add(bPrevious);
			panButton.add(bNext);

			saves.add(panButton, BorderLayout.SOUTH);
			
			this.setContentPane(saves);
			this.repaint();
			this.revalidate();
		}
		else
		{
			Log.mLog("mDrawSaves : probl�mes de parametre");
		}
	}
	

	
	public void mDrawGame( String[][] pTableau, int pWhiteEaten, int pBlackEaten, boolean ZenIsAlive)
	{
		
		JPanel game = new JPanel();
		game.setLayout(new BorderLayout() );
		game.setBackground( new Color(150,150,150));

		JPanel center = new JPanel();
			center.setLayout(new BorderLayout() );
			JLabel spaceGridNorth = new JLabel(" ");
			JLabel spaceGridSouth = new JLabel(" ");
			JLabel spaceGridEast = new JLabel("    ");
			JLabel spaceGridWest = new JLabel("    ");
			JPanel grid = new JPanel();
			grid.setLayout( new GridLayout(11,11,2,2) );
			JButton[][] gridButton = new JButton[11][11];
			for (int l = 0; l < 11; l++)
			{
				for (int c = 0; c < 11; c++)
				{
					gridButton[l][c] = new JButton( "" + pTableau[l][c] );
					grid.add(gridButton[l][c]);
					int line = l;
					int column = c;
					gridButton[l][c].addActionListener( (event) -> aControleur.mCaseClicked(line, column) );
				}		
			}

		JPanel left = new JPanel();
			left.setLayout( new BorderLayout() );
			// Creation de chaque boutons
			JPanel north = new JPanel();
				JPanel buttons = new JPanel();
				buttons.setLayout( new GridLayout(3,1,10,10) );
				JButton lobby = new JButton("Menu");
					lobby.addActionListener( (event) -> mDrawMenu() );
					lobby.setPreferredSize(new Dimension(200,45));
					
				JButton rules = new JButton("Regles");
					rules.addActionListener( (event) -> mDrawRules(1,0, aControleur ) );
					rules.setPreferredSize(new Dimension(150,45));
					
				JButton saves = new JButton("Sauvegarde");
					saves.setPreferredSize(new Dimension(150,45));
					saves.addActionListener( (event) -> SaveIg() );

					
		
			JPanel south = new JPanel();
			south.setLayout( new BorderLayout() );
				JLabel spaceGameInfoSouth = new JLabel(" ");
				JLabel spaceGameInfoEast = new JLabel("     ");
				JLabel spaceGameInfoWest = new JLabel("     ");
				JPanel gameInfo = new JPanel();
					gameInfo.setLayout( new BorderLayout() );
					gameInfo.setBackground( new Color(150,150,250));
						JLabel tour = new JLabel("Tour n�10");
						JLabel whiteKill = new JLabel(" Blanc manger:" + pBlackEaten );
						JLabel blackKill = new JLabel(" Noir manger:" + pWhiteEaten);	
						
		game.add(center, BorderLayout.CENTER);
			center.add(spaceGridNorth, BorderLayout.NORTH);
			center.add(spaceGridSouth, BorderLayout.SOUTH);
			center.add(spaceGridEast, BorderLayout.EAST);
			center.add(spaceGridWest, BorderLayout.WEST);
			center.add(grid, BorderLayout.CENTER);
		game.add(left, BorderLayout.WEST);
			left.add(north, BorderLayout.NORTH);
				north.add(buttons);
				buttons.add(lobby);
				buttons.add(rules);
				buttons.add(saves);
			left.add(south, BorderLayout.SOUTH);
				left.add(spaceGameInfoSouth, BorderLayout.SOUTH);
				left.add(spaceGameInfoEast, BorderLayout.EAST);
				left.add(spaceGameInfoWest, BorderLayout.WEST);
				left.add(gameInfo, BorderLayout.CENTER);
					gameInfo.add(tour, BorderLayout.NORTH );
					gameInfo.add(whiteKill, BorderLayout.CENTER );
					gameInfo.add(blackKill, BorderLayout.SOUTH );
					
	
	
	
	
		this.setContentPane(game);
		this.repaint();
		this.revalidate();
	}
	
	public void mDrawCredits()
	{
		JPanel credits = new JPanel();
		credits.setLayout(new BorderLayout() );
		
		//Affichage du Titre de la page en haut
		JLabel title = new JLabel("Credits");
		credits.add(title, BorderLayout.NORTH);

		// Grid Layout affichant les credits au millieu de la page
	
		
		JLabel cdLab = new JLabel("Jeux programm� sous Java \n"
				+ "Par Allan Bernier dans le cadre du projet de programmation\n"
				+ "du DUT informatique de Vannes.\n");
		
		credits.add(cdLab, BorderLayout.CENTER);

	

		
		
		// Affichage du bouton retour  en bas
		JButton back = new JButton("Retour");
		back.addActionListener( (event) -> mDrawMenu() );
		credits.add(back, BorderLayout.SOUTH);
		
		
		// Mise a jout du contentPane
		this.setContentPane(credits);
		this.repaint();
		this.revalidate();
	}
	
	
	
	/**
	 * Cette methode ouvre une boite de dialogue lorceque le bouton save est cliquer pendant une partie
	 * Cette JDialog permet de choisir quelle sauvegarde ecraser.
	 */
	  @SuppressWarnings("static-access")
	public void SaveIg()
	  {
		  String[] save = new String[5];
		    
		    for (int i = 0; i < 5; i++)
		    {
		    	Load load = new Load(i);
		    	save[i] = "Sauvegarde n�" + i + " tour n�" + load.getNoTurn();
		    }
		 
		    JOptionPane jop = new JOptionPane(), jop2 = new JOptionPane();
		    String nom = (String)jop.showInputDialog(null, 
		      "Veuillez indiquer la partie � ecraser!",
		      "Sauvegarde Dialog!",
		      JOptionPane.INFORMATION_MESSAGE,
		      null,
		      save,
		      save[0]);
		    // Si le joueur clique sur annul� la partie ne dois pas etre sauvegard�
		    if (nom != null)
		    {
		    	this.aControleur.mSave((int) (nom.charAt(13) ) ); // CECI EST DANGEREUX 
			    jop2.showMessageDialog(null, "Votre partie est sauvegard�e");

		    }
	  }
}









