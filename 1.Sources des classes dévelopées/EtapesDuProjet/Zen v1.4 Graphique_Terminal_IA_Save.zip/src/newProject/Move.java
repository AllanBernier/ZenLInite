package newProject;

/**
 * Cette classe plermet de calculer tout les deplacements possible pour un pion en lui envoyant sa couleur, le plateau et sa position
 * @author Allan Bernier
 * @since 18/04/20
 */
public final class Move
{
	int[][] aPlateau;
	int aLine;
	int aColumn;
	int aColor;
	int[][] aMove;
	int aZenColor;



	/**
	* @param pPlateau l'etat actuel de plateau
	* @param pLine la ligne du pion
	* @param pColumn la colonne du pion
	* @param pColor la couleur du pion
	*/
	public Move(int[][] pPlateau, int pLine, int pColumn, int pColor)
	{
		this.aPlateau = pPlateau;
		this.aLine = pLine;
		this.aColumn = pColumn;
		this.aColor = pColor;
		this.aMove = new int[8][3];
		this.aZenColor = 2;
		mMovePion();
		
	}
	
	/**
	 * Compte le nombre de pions pr�sent dans la ligne et renvoit cette valeur

	 */
	private int mNbInLigne()
	{
		int ret = 0;
		if (aPlateau != null && aLine >= 0 && aLine < 11 && aColumn >= 0 && aColumn < 11)
		{
	 		
			for (int i = 0; i < 11; i++) // 11 correspond � la taille de la map
			{
				if ( aPlateau[aLine][i] != 0 ) // Si il y � un pion sur la ligne
				{
					ret ++; // Le nombre de pions pr�sent augmente de 1
				}
			}
		}
		else
		{
			System.err.println("==Problemes de parametres==");
		}
		return ret;
	}
	
	/**
	 * Compte le nombre de pions pr�sent dans la colonne et renvoit cette valeur
	 * @param aPlateau la map ou sont plac� les pions
	 * @param aLine le placement y de notre pion ( x et y sont invers� � ligne colonne !)
	 * @param aColumn le placement x de notre pion
	 * @return Le nombre de pions pr�sent dans la colonne
	 */
	private int mNbInColonne()
	{
		int ret = 0;
		if (aPlateau != null && aLine >= 0 && aLine < 11 && aColumn >= 0 && aColumn < 11)
		{
			
			for (int i = 0; i < 11; i++) // 11 correspond � la taille de la map
			{
				if ( aPlateau[i][aColumn] != 0 ) // Si il y � un pion sur la ligne
				{
					ret ++; // Le nombre de pions pr�sent augmente de 1
				}
			}
		}
		else
		{
			System.err.println("==Problemes de parametres==");
		}
		return ret;
	}
	
	/**
	 * Compte le nombre de pions pr�sent dans la diagonale de gauche et renvoit cette valeur
	 * (diagonal de gauche CAD de haut gauche jusqu'a bas droite)
	 * @param aPlateau la map ou sont plac� les pions
	 * @param aLine le placement y de notre pion ( x et y sont invers� � ligne colonne !)
	 * @param aColumn le placement x de notre pion
	 * @return Le nombre de pions pr�sent dans la diagonal
	 */
	private int mNbInDiagonalGauche()
	{
		int ret = 0;
		if (aPlateau != null && aLine >= 0 && aLine < 11 && aColumn >= 0 && aColumn < 11)
		{
			int diagonal;
			if (aColumn > aLine)
			{
				diagonal = aColumn - aLine; // Num�ro de la diagonal
				int nbVal = 11 - diagonal; // nombre de valeurs dans la diagonal
//				System.out.println("nbVal ="+nbVal + "\tdiagonal =" + diagonal ); // Ligne utile seulement pour d�bug
				for (int i = 0; i < nbVal; i ++) // Pour chaque case de cette diagonal
				{
//					System.out.println("ligne =" + i +"\tColonne ="+ (diagonal + i) + "\tmap[ligne][colonne] =" + aPlateau[i][diagonal + i] ); // Ligne utile seulement pour d�bug
					if ( aPlateau[i][diagonal + i] != 0 ) // Si il y � un pion dedans
					{
						ret ++;
					}
				}
			}
			else
			{
				diagonal = aLine - aColumn; // Num�ro de la diagonal
				int nbVal = 11 - diagonal; // nombre de valeurs dans la diagonal
//				System.out.println("nbVal ="+nbVal + "\tdiagonal =" + diagonal ); // Ligne utile seulement pour d�bug
				for (int i = 0; i < nbVal; i ++) // Pour chaque case de cette diagonal
				{
//					System.out.println("ligne =" + (diagonal + i) +"\tColonne ="+ i + "\tmap[ligne][colonne] =" + aPlateau[diagonal + i][i] ); // Ligne utile seulement pour d�bug
					if ( aPlateau[diagonal + i][i] != 0 ) // Si il y � un pion dedans
					{
						ret ++;
					}
				}
			}
			
		
		}
		else
		{
			System.err.println("==Problemes sur les attributs==");
		}
		return ret;
	}
	
	/**
	 * Compte le nombre de pions pr�sent dans la diagonale de gauche et renvoit cette valeur
	 * (diagonal de droite CAD de haut droite jusqu'a bas gauche)
	 * @param aPlateau la map ou sont plac� les pions
	 * @param aLine le placement y de notre pion ( x et y sont invers� � ligne colonne !)
	 * @param aColumn le placement x de notre pion
	 * @return Le nombre de pions pr�sent dans la diagonal
	 */
	private int mNbInDiagonalDroite()
	{
		int ret = 0;
		if (aPlateau != null && aLine >= 0 && aLine < 11 && aColumn >= 0 && aColumn < 11)
		{
			int diagonal;
			if (aLine + aColumn <= 10 )
			{
				diagonal =10 - (aColumn + aLine); // Num�ro de la diagonal
				int nbVal =11 - diagonal; // nombre de valeurs dans la diagonal
//				System.out.println("nbVal ="+nbVal + "\tdiagonal =" + diagonal ); // Ligne utile seulement pour d�bug
				for (int i = 0; i < nbVal;i ++)
					{
//					System.out.println("ligne =" + i +"\tColonne ="+  (10-(diagonal + i)) + "\tmap[ligne][colonne] =" + aPlateau[i][10-(diagonal + i)] ); // Ligne utile seulement pour d�bug
					if ( aPlateau[i][10-(diagonal + i)] != 0 )
					{
						ret ++;
					}
				}
			}
			else
			{
				diagonal = (aLine + aColumn) - 10 ; // Num�ro de la diagonal
				int nbVal =11 - diagonal; // nombre de valeurs dans la diagonal
//				System.out.println("nbVal ="+nbVal + "\tdiagonal =" + diagonal ); // Ligne utile seulement pour d�bug
				for (int i = 0; i < nbVal;i ++)
					{
//					System.out.println("ligne =" + ((10-(nbVal-1)) + i) +"\tColonne ="+  (10 - i) + "\tmap[ligne][colonne] =" + aPlateau[10-(nbVal-1) + i][10 - i] ); // Ligne utile seulement pour d�bug
					if ( aPlateau[(10-(nbVal-1)) + i][10 - i] != 0 )
					{
						ret ++;
					}
				}
			}
		
		}
		else
		{
			System.err.println("==Problemes de parametres==");
		}
		return ret;
	}

	/**
	 * Cette methode renvoit un tableau sous la forme 
	 * {l,c,b},{l,c,b}... des 8 la cases ou le pions peut se pr�tendument se d�placer en ligne et colonne
	 * Ce tableau ne test pas les conditions de sortie de carte ou autres !!
	 * tab[0] correspond au d�placement en ligne vers la haut
	 * tab[1] correspond au d�placement en ligne vers la bas 
	 * tab[2] correspond au d�placement en colonne vers le droite
	 * tab[3] correspond au d�placement en colonne vers le gauche
	 * tab[4] correspond au d�placements en diagonal en haut a gauche
	 * tab[5] correspond au d�placements en diagonal en bas a droite
	 * tab[6] correspond au d�placements en diagonal en haut a droite
	 * tab[7] correspond au d�placements en diagonal en bas a gauche
	 * @param aPlateau la map servant � r�cuperer les valeurs
	 * @param aLine la ligne de position du pion
	 * @param aColumn la colonne de position du pions
	 * @return le tableau de deplacements
	 */
	private int[][] mBrutMovePion()
	{
		int ret[][] = new int [8][2];
		int dpInLigne 			= mNbInLigne();
		int dpInColonne 		= mNbInColonne();
		int dpInDiagonalGauche	= mNbInDiagonalGauche();
		int dpInDiagonalDroite	= mNbInDiagonalDroite();
		
		// D�placements posible en Ligne pour le pion en aLine, aColumn
		
		ret[0][0] = aLine - dpInColonne;
		ret[0][1] = aColumn;
		
		ret[1][0] = aLine + dpInColonne;
		ret[1][1] = aColumn;

		// D�placements posible en Colonne pour le pion en aLine, aColumn
		ret[2][0] = aLine;
		ret[2][1] = aColumn + dpInLigne;
		
		ret[3][0] = aLine;
		ret[3][1] = aColumn - dpInLigne;
		
		// D�placements posible en Diagonal Gauche pour le pion en aLine, aColumn
		ret[4][0] = aLine - dpInDiagonalGauche;
		ret[4][1] = aColumn - dpInDiagonalGauche;
		
		ret[5][0] = aLine + dpInDiagonalGauche;
		ret[5][1] = aColumn + dpInDiagonalGauche;
	
		// D�placements posible en Diagonal Droite pour le pion en aLine, aColumn	
		ret[6][0] = aLine + dpInDiagonalDroite;
		ret[6][1] = aColumn - dpInDiagonalDroite;
		
		ret[7][0] = aLine - dpInDiagonalDroite;
		ret[7][1] = aColumn + dpInDiagonalDroite;
		
		return ret;
	}

	/** 
	 * Verifie que le deplacement ne saute pas un pion d'une autre couleur 
	 * OU
	 * que le deplacement ne s'arrete pas sur une case de sa couleur !
	 * Renvoie un tableau avec les 8 d�placements differents 
	 * 1 si le deplacement est possible
	 * 2 si le deplacement chevauche un pion ennemie OU si le deplacement est sur un de mes pions
	 * 3 si le deplacement tue un pion ennemie!
	 * 4 si hors de la map
	 */
	public void mMovePion()
	{
		int[][] move = new int[8][2];
		int[] dest = new int[8];
		int[] chemin = new int[8];
		if (aColor == 1 || aColor == -1) // Si la couleur est bonne
		{
			// Recupere les deplacement possible avant verification.
			move = mBrutMovePion();

			//Verifie si la destination est possible.
			dest = mVerifDestination(move);
			 
			//Verifie si le chemin est possible.
			chemin = mVerifChemin(move, dest);
		}
		else
		{
			System.err.println("La couleur du joueur n'existe pas !");
		}
		
		
		//Remplissage du tableau de deplacement
		for (int i = 0; i < 8; i++)
		{
			aMove[i][0] = move[i][0];
			aMove[i][1] = move[i][1];
			aMove[i][2] = chemin[i];
			
			// Print du tableau de deplacement
			// System.out.println("deplacement " + i + ":\t" + aMove[i][0] +"\t"+ aMove[i][1] +"\t"+ aMove[i][2]  );

		}
		
	}
	
	/**
	 * Regarde pour chaque case entre la position du pion et la destination si il y a un pion ennemie
	 * @param aPlateau le plateau actuelle
	 * @param aLine la ligne du pion
	 * @param aColumn la colonne du pion
	 * @param aColor la couleur du pion
	 * @param pMove tableau sous forme t[0] = ligne t[1] = colonne contenant la destination du pion
	 * @param pDest tableau avec une indication sur chaque destination pour savoir si il faut trait� la direction ou non 
	 * @return tableau de int de 1 a 4
	 * 1 si le deplacement est possible
	 * 2 si le deplacement chevauche un pion ennemie OU si le deplacement est sur un de mes pions
	 * 3 si le deplacement tue un pion ennemie!
	 * 4 si hors de la map
	 */
	private int[] mVerifChemin(int[][] pMove, int[] pDest) // ToDo
	{
		int[] ret = pDest;
		
		//Haut  -- Fait !
		int haut = 0;
		if (ret[haut] != 4 && ret[haut] != 2 ) // Si la destination est possible..
		{
//			System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[haut][0] + "\taLineDest " + pMove[haut][1]);
			for (int i = aLine - 1 ; i > pMove[haut][0] ; i--) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[ i ][ pMove[haut][1] ] != 0 && aPlateau[ i ][ pMove[haut][1] ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[haut] = 2;
				}
			}
		}	
		
		// Bas -- Fait !
		int bas = 1;
		if (ret[bas] != 4 && ret[bas] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[bas][0] + "\taLineDest " + pMove[bas][1]);
			for (int i = aLine + 1 ; i < pMove[bas][0] ; i++) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[i][ pMove[bas][1] ] != 0 && aPlateau[i][ pMove[bas][1] ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[bas] = 2;
				}
			}
		}			
			
		// Droite -- Fait !
		int droite = 2;
		if (ret[droite] != 4 && ret[droite] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[droite][0] + "\taLineDest " + pMove[droite][1]);
			for (int i = aColumn + 1 ; i < pMove[droite][1] ; i++) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[ pMove[droite][0] ][ i ] != 0 && aPlateau[ pMove[droite][0] ][ i ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[droite] = 2;
				}
			}
		}	
			
		// Gauche -- Fait !
		int gauche = 3;
		if (ret[gauche] != 4 && ret[gauche] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[gauche][0] + "\taColumnDest " + pMove[gauche][1]);
			for (int i = aColumn - 1 ; i > pMove[gauche][1] ; i--) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[ pMove[gauche][0] ][ i ] != 0 && aPlateau[ pMove[gauche][0] ][ i ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[gauche] = 2;
				}
			}
		}		
			
		// Haut-Gauche -- Fait !
		int hg = 4; 
		if (ret[hg] != 4 && ret[hg] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[hg][0] + "\taColumnDest " + pMove[hg][1]);
			for (int i = 1 ; i < aLine - pMove[hg][0] ; i++) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if ( aPlateau[aLine - i ][aColumn - i] != 0 && aPlateau[aLine - i ][aColumn - i] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor ){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[hg] = 2;
				}
			}
		}			
		
		// Bas-Droite -- Fait !
		int bd = 5; 
		if (ret[bd] != 4 && ret[bd] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[bd][0] + "\taColumnDest " + pMove[bd][1]);
			for (int i = 1 ; i < pMove[bd][0] - aLine  ; i++) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[ aLine + i ][ aColumn + i  ] != 0 && aPlateau[ aLine + i ][ aColumn ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[bd] = 2;
				}
			}
		}		
			
			
			
		// Bas-Gauche -- Fait
		int bg = 6; 
		if (ret[bg] != 4 && ret[bg] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[bg][0] + "\taColumnDest " + pMove[bg][1]);
			for (int i = 1 ; i < pMove[bg][0] - aLine ; i++) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[aLine + i ][ aColumn - i ] != 0 && aPlateau[aLine + i ][ aColumn - i ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[bg] = 2;
				}
			}
		}		
		
		// Haut-Droit
		int hd = 7; 
		if (ret[hd] != 4 && ret[hd] != 2 ) // Si la destination est possible..
		{
//				System.out.println("ligne "+ aLine + "\tColonne " + aColumn + "\taLineDest " + pMove[hd][0] + "\taColumnDest " + pMove[hd][1]);
			for (int i = 1 ; i < aLine - pMove[hd][0] ; i++) // Ce for test toute les valeurs entre la position initiale et la destination 
			{
				if (aPlateau[ aLine - i ][ aColumn + i ] != 0 && aPlateau[ aLine - i ][ aColumn + i ] != aColor && aPlateau[ i ][ pMove[haut][1] ] != aZenColor ){ // Si la case est ni vide, ni notre pion, alors on chevauche un pion ennemie
					ret[hd] = 2;
				}
			}
		}	
		return ret;
	}
	
	/**
	 * Verifie si la destination du pion est possible dans chaqu'une des dirrection ( seulement la destination, pas le chemain pour y aller
	 * 1 si le deplacement est possible
	 * 2 si le deplacement chevauche un pion ennemie OU si le deplacement est sur un de mes pions
	 * 3 si le deplacement tue un pion ennemie!
	 * 4 si hors de la map
	 * @param aPlateau la position actuelle des pions sur le plateau
	 * @param aLine la ligne actuelle du pion
	 * @param aColumn la colonne actuelle du pion
	 * @param aColor la couleur du pion a bouger
	 * @param pDest les destination "possible" du pion
	 * @return Un tableau de int de 8 elements avec chaque cas pour chaque direction.
	 */
	private int[] mVerifDestination( int[][] pDest)
	{
		int[] ret = new int[8];
			for (int i = 0; i < 8 ; i++) // Pour chaque deplacement possible 
			{
				if ( pDest[i][0] < 11 && pDest[i][0] >= 0 && pDest[i][1] < 11 && pDest[i][1] >= 0 ) // Verifier que la destination de sors pas du plateau 
				{
					if ( aPlateau[ pDest[i][0] ][ pDest[i][1] ] == aColor ) // Si le pion d'arriver est de sa couleur
					{
						ret[i] = 2; // destination impossible
					}
					else if ( aPlateau[ pDest[i][0] ][ pDest[i][1] ] != aColor && aPlateau[ pDest[i][0] ][ pDest[i][1] ] != 0 ) // Sinon si le pion d'arriver est different de sa couleur et different de 0 ( donc un pion ennemie )
					{
						ret[i] = 3; // tue un pion ennemie
					}
					else 
					{
						ret[i] = 1; // destination possible
					}
				}
				else
				{
				 ret[i] = 4; // depacement de carte
				}
			}
		return ret;
	}

	/**
	 * @return the aMove
	 */
	public int[][] getMove() 
	{
		return this.aMove;
	}
}



















