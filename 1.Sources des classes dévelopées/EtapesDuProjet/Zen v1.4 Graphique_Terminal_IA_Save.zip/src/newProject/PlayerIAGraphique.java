package newProject;

public class PlayerIAGraphique extends PlayerGraphique 
{


	public PlayerIAGraphique(int pColor, Zen pZen)
	{
		super(pColor, pZen);
	}
	
	/**
	 * Recoit un ligne et une colonne et remplie les tableau aPion et aWhere en fonction de l'avancement du tour
	 * @param pZen
	 * @param pPlateau
	 * @param aNoTurn
	 * @param aMode
	 * @param pLine
	 * @param pColumn
	 * @return
	 */
	public void mPlay(Zen pZen, int[][] pPlateau, int pNoTurn) {

		this.aPlateau = pPlateau;
		this.aZen = pZen;
		this.aNoTurn = pNoTurn;
		
		
		int[][] posPions = mGetPosPions(); // Recupere les coordonee de chaque pions
		double[] cloudP = mCloudPoint(posPions); // Recupere le nuage de points grace au tableau de pion
		
		System.out.println("Coordonee de chaque pions");
		for(int i = 0; i < posPions.length ; i++)
		{
			System.out.print(posPions[i][0] + "," + posPions[i][1] + "    ");
		}
		
		 //recupere les coodronee du pion le plus loin du nuage et les met dans "this.aPion"
		double dist = 0;
		double pionDist;
		
		System.out.println("\n\nCalculDist  " );

		for (int i = 0; i < posPions.length; i++)
		{
			pionDist = mGetDist( posPions[i][0] , posPions[i][1]  , cloudP[0] , cloudP[1] );
			System.out.println("La distance du pion est  " + posPions[i][0] + " "  + posPions[i][1] + "  " + pionDist);

			if ( pionDist > dist )
			{
				dist = pionDist;
				this.aPion[0] = posPions[i][0];
				this.aPion[1] = posPions[i][1];
			}
		}
		
		System.out.println("Le pion le plus loin  est  " + aPion[0] + " "  + aPion[1]);
		// recupere les coodronee rapprochant le plus du nuage de points dans les deplacements possible de aPion
		dist = 100;
		int[][] move = new  Move( this.aPlateau ,this.aPion[0]  , this.aPion[1] , this.aColor ).getMove();

		System.out.println("\n\n Calcul dist des moves");
		
		for (int i = 0; i < move.length; i++)
		{
			if (move[i][2] == 1 || move[i][2] == 3) // Si le pion peux bouger
			{

				pionDist = mGetDist( move[i][0] , move[i][1]  , cloudP[0] , cloudP[1] );
				System.out.println("La distance move, cloud est  " + move[i][0] + " "  + move[i][1] + "  " + pionDist);

				if ( pionDist < dist )
				{
					dist = pionDist;
					this.aWhere[0] = move[i][0];
					this.aWhere[1] = move[i][1];
					
					System.out.println("aWhere " + this.aWhere[0] + "   " + this.aWhere[1]);
				}
			}
		}
		
		
				
	}
	
	/**
	 * Retourne le nuage de points correspondant au millieu entre tout les pions du joueur present sur le plateau
	 * @param pTab Le plateau de jeu
	 * @param pionPos La position de chaque pion en jeu.
	 * @return Double, la valeur du nuage de points
	 */
	public double[] mCloudPoint(int[][] pPionPos)
	{
		int line = 0;
		int column = 0;
		int nbPion = 0;
		

		for (int i = 0; i < pPionPos.length; i ++)
		{
			line += pPionPos[i][0];
			column += pPionPos[i][1];
			nbPion ++;
		}
			
		double[] cloud = new double[2];
		cloud[0] =  ( (double) (line) / (double) (nbPion) );
		cloud[1] = (  (double) (column)  / (double) (nbPion) );
		
		System.out.println("Cloud " + cloud[0] + "," + cloud[1]);
		return cloud;
	}
	
	/**
	 * Renvoie la distance entre deux position.
	 * @param x1 line of point 1 
	 * @param y1 column of point 1 
	 * @param x2 line of point 2
	 * @param y2 column of point 2
	 * @return double, correspond a la distance.
	 */
	public double mGetDist(int x1,int y1,int x2,int y2)
	{		
	    return (Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))); // ~= pytagore
	}
	
	/**
	 * Renvoie la distance entre deux position, une position en int et une en double.
	 * @param x1 line of point 1 
	 * @param y1 column of point 1 
	 * @param x2 line of point 2
	 * @param y2 column of point 2
	 * @return double, correspond a la distance.
	 */
	public double mGetDist(int x1,int y1,double x2,double y2)
	{		
	    return (double) (Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))); // ~= pytagore
	}
	
	/**
	 * Cherche la position de tout mes pions sur le plateau.
	 * @return tableau de int avec tab[0][0] = line du pion et tab[0][1] = colonne du pion.
	 */
	public int[][] mGetPosPions()
	{
		int[][] pions = new int[12][2];
		int index = 0;
		
		for( int l = 0; l < this.aPlateau.length; l++)
		{
			for( int c = 0; c < this.aPlateau[l].length; c++)
			{
				if (this.aPlateau[l][c] == this.aColor && index < 12)
				{
					pions[index][0] = l;
					pions[index][1] = c;
					System.out.println(pions[index][0] + ";" + pions[index][1] + "  " + index + "  " + this.aPlateau[l][c] + " " + l + " " + c);

					index ++;

				}
			}
		}
		
		int[][] ret = new int[index][2];
		for (int i = 0; i < index ; i ++)
		{
			ret[i][0] = pions[i][0];
			ret[i][1] = pions[i][1];
		}
		
		return ret;
		
	}
	
	/**
	 * Print les attribut de la classe dans son etat actuel.
	 */
	public void mToString()
	{
		System.out.println("==PlayerHumanGraphique==");
		System.out.println("aPionSelected: " + this.aPionSelected );
		System.out.println("aEndTurn: " + this.aEndTurn );
		System.out.println("aPion: " + this.aPion[0] + "  " +  this.aPion[1] );
		System.out.println("aWhere: " + this.aWhere[0] + "  " +  this.aWhere[1] );
		System.out.println("aColor: " + this.aColor );
		System.out.println("========================" );
	}
	
	
	
}











