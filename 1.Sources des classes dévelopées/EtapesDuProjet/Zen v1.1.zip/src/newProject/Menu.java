package newProject;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu extends JFrame{
	private static final long serialVersionUID = 7353056081987644865L;

	
	
	
	
	
	
	private JLabel title;
	private JButton playOnline;
	private JButton OneVsOne;
	private JButton twoVsTwo;
	private JButton playerVsIA;
	private JButton saves;
	private JButton rules;
	private JButton credits;
	private JButton quit;
	
	
	
	public Menu(String pTitre) 
	{
		super(pTitre);
		// quitter le programme lorsqu'on ferme la fen�tre
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(900, 600);
		
	    //D�finition de sa couleur de fond
	  //  pan.setBackground(Color.ORANGE);        
	    //On pr�vient notre JFrame que notre JPanel sera son content pane
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		JPanel pan = (JPanel) this.getContentPane();
		pan.setLayout(new FlowLayout() );

		


		// Initialisation de chaque composants graphique
		this.title = new JLabel("Zen l'initie");
					
		this.playOnline = new JButton("Play Online");
		this.OneVsOne = new JButton("Play One vs One");
		this.twoVsTwo = new JButton("Play Two Vs Two");
		this.playerVsIA = new JButton("Play vs IA");
		this.saves = new JButton("Saves");
		this.rules = new JButton("Rules");
		this.credits = new JButton("Credits");
		this.quit = new JButton("Quit");
		
		this.playOnline.addActionListener( (event) -> new MenuSave("Save"));
		
		pan.add(playOnline);
		pan.add(OneVsOne);
		pan.add(twoVsTwo);
		pan.add(playerVsIA);
	}
	
}
