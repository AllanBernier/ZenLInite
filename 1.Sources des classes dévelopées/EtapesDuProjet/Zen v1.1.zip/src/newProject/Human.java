package newProject;

public class Human extends Player{
	
	public Human(Zen pZen, int[][] pPlateau, int noTurn)
	{
		super(pZen,pPlateau,noTurn);
	}

	
	
}
