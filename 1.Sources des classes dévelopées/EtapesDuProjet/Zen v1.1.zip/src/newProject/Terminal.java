package newProject;

import java.util.Scanner;

/**
 * Cette classe a juste besoin d'etre instancier pour lancer le jeux
 * Tout le jeu se deroule en terminal.
 * @author Bernier Allan
 */
public class Terminal {
	
	Scanner sc;			// Interaction uttilisateur 
	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu
	int aTurnToPlay; 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
	int aMode;
	
	public Terminal() 
	{
		 this.sc = new Scanner(System.in);
		new Log("Lancement du menu en mode Terminal");
		 mMenu();
	}
	
	/**
	 * Lance le menu puis  en retour lance une fenetre comprise entre 1 et 6 corespondant aux differentes fenetre possible a afficher
	 */
	public void mMenu()
	{
		System.out.println("1: Player Vs IA (pas fait)");
		System.out.println("2: Player vs Player");
		System.out.println("3: 2 Player Vs 2 Player (pas fait)");
		System.out.println("4: Regles");
		System.out.println("5: Sauvegardes");
		System.out.println("6: Quitter");
		System.out.println("7: Credits ");
		
		int choix = -1;
		do 
		{
			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e)
			{
				new Log("mMenu : tryCatch - NumberFormatException");
			}				
		}while ( choix <= 0 || choix > 7);
		
		mRunMenu( choix , 8); // Lance le menu correspondant (8 etant le menu
	}
	
	/**
	 * Lance les differents elements graphique que le joueur voudrais afficher
	 * @param pFrame Le menu a lancer
	 * @param pFrom	Le lieux d'appel de la fonction
	 */
	public void mRunMenu(int pFrame, int pFrom)
	{
		if (pFrame > 0 && pFrame <= 8)
		{
			switch(pFrame)
	        {
	            case 1:
	        		new Log("Joue en Player vs IA");
	        		System.out.println("== Player Vs IA == ");
	        		mMenu();
	            break;
	            
	            case 2:
	        		new Log("Joue en Player vs Player");
	        		System.out.println("== Player vs Player == ");
	        		this.aTurnToPlay = mChoiceColor();
	        		this.aPlateau = mInitPlateau(); // Plateau de debut de partie
	        		this.aZen = new Zen();
	        		this.aMode = 2;
	        			mTurn();
	        			
	            break;
	            
	            case 3:
	        		new Log("Joue en 2 Player vs 2 Player");
	        		System.out.println("== 2 Player Vs 2 Player == ");
	        		mMenu();
	        	break;
	        	
	            case 4:
	        		new Log("Ouverture du menu Regles");
	        		System.out.println("== Regles == ");
	        		mRules();
	        		mMenu();
	            break;
	            
	            case 5:
	        		new Log("Ouverture du menu Sauvegardes");
	        		System.out.println("== Sauvegardes == ");
	        		mSaves();
	        		mMenu();
	            break;
	            
	            case 6:
	        		new Log("Fin du jeux : le programme s'est termin� sans probl�mes");
	        		System.out.println("== Quitter == ");
					System.exit(0); 
	            break;
	            
	            case 7:
	        		new Log("Ouverture du menu Credits");
	        		System.out.println("== Credits == ");
	        		mCredits();
	        		mMenu();
	            break;
	        }
		}
	}
	
	/**
	 * affiche les r�gles 1 par 1 avec un scaner pour passer de l'une a l'autre
	 * Si on envoit 1 au scaner il lit la r�gle precedent
	 * 2 il retourne a la derni�re fenetre d'ou il a ete appeler
	 * 3 il lit la regle suivante.
	 */
	public void mRules()
	{
		String[] sRules = {
				"Debut de la partie: \n"
				+ "Chaque joueur choisit une couleur blanc ou noir\n"
				+ "Le pion Zen est au centre du plateau\n"
				+ "Le joueur qui commence est tir� au sort.\n"
			,				
				"But du jeu: \n"
				+ "Le vainqueur est le premier joueur qui reussit a former une chaine continue\n"
				+ "avec la totalit� de ses pions y compris le Zen si celui-ci est encore en jeu.\n"
			,				
				"Deroulement de la partie: \n"
				+ "Chaque joueur deplace a son tour un pion de sa couleur ou le Zen en respectant 4\n"
				+ "regles tres simple."
			,				
				"Regle 1: \n"
				+ "Les pions se deplacent en ligne droite dans nimporte quelle\n"
				+ "direction (ligne, colonne, diagonales)\n"
				+ "Tout pions doit toujour se deplacer d'autant de cases qu'il y a de pions sur la ligne de\n"
				+ "deplacement choisie\n"
				+ "(Tout les pions y compris le pion deplace"
			,				
				"Regle 2: \n"
				+ "Tout pion peut passer par dessus un ou plusieur pions de sa couleur mais \n"
				+ "jamais par dessus ceux de son adversaire !"
			,				
				"Regle 3: \n"
				+ "Tout pion peut capturer un pion adverse en se placant sur la case occupe par le pion en respectant la regle 1"
			,				
				"Regle 4: \n"
				+ "a chaque coup, le Zen, pion commun a tous les joueurs peut �tre soit blanc, soit noir\n"
				+ "selon l'interet de celui qui joue "
			,				
				"Particularite autour du Zen:"
				+ "\ta) Lorcequ'il est deplacer par un joueur, son adversaire n'a pas\n"
				+ "le droit de le replacer sur la meme case au tour suivant\n"
				+ "\n"
				+ "\tb) Il est interdit de le deplacer si il ne se trouve pas en contact avec\n"
				+ "au moins un autre pion (blanc ou noir)"
			,				
				"Match Null: \n"
				+ "Si en fin de partie un joueur finis au meme coup, son graph et celui de son adversaire"				
			};
		
		
		int actualRule = 0;
		int choix = -1;

		do 
		{
			if (choix == 1) 
			{
				actualRule --;
			}
			else if ( choix == 3)
			{
				actualRule ++;
			}
			if (actualRule >= sRules.length )
			{
				actualRule = 0; 
			}
			else if (actualRule < 0)
			{
				actualRule = sRules.length - 1 ; 
			}
			System.out.println(sRules[actualRule] + "\n\n" + " 1: Precedent \t 2: Retour \t 3: Suivant");

			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e)
			{
				new Log("mRules : tryCatch - NumberFormatException");

			}				
		}while ( choix != 2 );
				
		// Si le choix est egale a 2, la fonction s'arette et retourne a son lieux d'appel		
		
	}
	
	/**
	 *	Demande au joueur de choisir une couleur entre eux entre noir et blanc 
	 *	Math.random leurs d�signe quel joueur commence 
	 * @return l'indice du joueur qui commence entre -1 et 1 avec -1 pour noir et 1 pour blanc
	 */
	public int mChoiceColor()
	{
		System.out.println("Choissez entre vous qui est le joueur Blanc et qui est le joueur noir ");
		System.out.println("appuyer sur [entrer] ");
		sc.nextLine();				

		System.out.println("1...");
		System.out.println("2...");
		System.out.println("3...");
        int ret = (int)(Math.random() * 2) + 1; 
        if (ret == 1 )
        {
    		System.out.println("Blanc commence !");
        }
        else
        {
    		System.out.println("Noir commence !");
    		ret = -1;
        }
		System.out.println("appuyer sur [entrer] ");
		sc.nextLine();
        return ret;
	}
	
	/**
	 * Renvoit le plateau du jeu initialise au tour 1. 
	 * @return le plateau de int a 2 dimensions
	 */
	public int[][] mInitPlateau()
	{
		int ret[][] =  {{1 ,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,-1},//0
						{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//1
						{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//2
						{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//3
						{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//4
						{-1,0 ,0 ,0 ,0 ,2 ,0 ,0 ,0 ,0 ,-1},//5
						{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//6
						{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//7 c 3 l 8
						{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//8
						{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//9
						{-1,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,1 } //10
					}; //0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10	
		return ret;
		
	}
	
	/**
	 * Cette methode g�re le tour entier pour un joueur, elle est r�cursive, elle vas s'appeler en boucle
	 * tant que la partie n'est pas fini.
	 */
	public void mTurn()
	{
		GameOver go1 = new GameOver(1 , aZen, aPlateau);
		GameOver go2 = new GameOver(-1, aZen, aPlateau);
		while( !( go1.mIsOver() ) && !(go2.mIsOver() ) ) // Continuer de jouer, tant que la partie n'est pas fini.
		{
			// Premierement, au debut du tour, affiche le plateau de jeux
			mAfficherPlateau();
			// Deuxiemement, dis quel joueur dois jouer 
			System.out.println("Au tour du joueur: " +  ( (this.aTurnToPlay == 1) ? "Blanc" : "Noir"));
    		new Log("Au tour du joueur: " +  ( (this.aTurnToPlay == 1) ? "Blanc" : "Noir"));

			// Ensuite, demander une action au joueur qui dois jouer
				// Le joueur peux envoyer une position sous la forme "A1" jusqu"a "K11"
				// Le joueur peux choisir de regarder les r�gles
				// Le joueur peut retourner au menu (quitter la partie)
				// Le joueur peut Quitter le jeu.
				// Le joueur peut sauvegarder la partie.		
			int[] pos = mVerifPos();
			// Recupere un tableau de deplacement possible pour ce pion
			Move mv = new Move(aPlateau, pos[0] , pos[1] , aTurnToPlay);
			int[][] pion = mv.getMove();
					
			if (aPlateau[ pos[0] ][ pos[1] ] == aZen.getZenColor() ) // Si le pion deplacer est le zen 
			{
				aZen.setLine(pos[0]);
				aZen.setColumn(pos[1]);
				pion = aZen.mZenMove(this.aPlateau, pion , this.aNoTurn); // On verifit � nouveau les deplacement mais concernant le zen
			}
			
			// Affiche les deplacements possible de ce pions
			mAfficherDeplacements(pion , pos);
			int[] move = mAskMove(pion);
			
			// Si le Zen viens d'etre d�palcer changer les valeurs du Zen

			if ( this.aPlateau[ pos[0] ][ pos[1] ]  == this.aZen.getZenColor() )
			{
				this.aZen.mRefreshZen(move[0], move[1], this.aNoTurn );
			}
			
			if (this.aPlateau[ pos[0] ][ pos[1] ] == aZen.getZenColor() ) // Si on se deplace sur le Zen, il meurt
			{
				aZen.setIsAlive(false);
			}
			
			new Log("Le joueur veut bouger le pion qui est en position [" + move[0] + "][" + move[1] +"]" );
			new Log("Le joueur a deplacer le pion jusqu'a la case [" + pos[0] + "][" + pos[1] +"]" );

			this.aPlateau[ move[0] ][ move[1] ] = this.aPlateau[ pos[0] ][ pos[1] ];	//Echanger le pion "pos" a la position "move" dans le plateau
	
			this.aPlateau[ pos[0] ][ pos[1] ] = 0;	// Le pion ayant bouger son ancienne position est maintenant � 0
					
			this.aNoTurn ++; // Le tour etait fini il augmande te 1
			
			// Le joueur ayant fini de jouer, il laisse jouer son adversaire
			
			if ( aTurnToPlay == 1)
			{
				this.aTurnToPlay  = -1;			
			}
			else
			{
				this.aTurnToPlay  = 1;		
			}
			
			go1 = new GameOver(1 , aZen, aPlateau);
			go2 = new GameOver(-1, aZen, aPlateau);
			
		}
		mAfficherPlateau();
		new Log("Fin de la partie, le gagnant est " + ( (go1.mIsOver() )? "Blanc" : "Noir"  ) );

		System.out.println("================LA PARTIE EST FINI===========================================");
	}
	
	/**
	 * Affiche le plateau de jeux avec les pions correspondant
	 * en transformant le tableau de int en parametre en ascii
	 */
	public  void mAfficherPlateau()// Plus tard les Lettres seront remplac� par des couleurs
	{

		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{
				if( this.aPlateau[l][c] == -1) // Noir
				{
					System.out.print("(Noir)\t");
				}
				else if( this.aPlateau[l][c] == 0) // Case vide
				{
					System.out.print("(     )\t");
				}
				else if( this.aPlateau[l][c] == 1 ) // Blanc
				{
					System.out.print("(Blanc)\t");
				}
				else if (this.aPlateau[l][c] == 2) // Zen l'initi�
				{
					System.out.print("( Zen )\t");
				}	
			}
			System.out.println( (11-l) + "\t\n" );
		}
		System.out.println("   A       B       C       D       E       F       G       H       I      J      K    ");
		System.out.println("________________________________________________________________________________________");

	}

	/**
	 * Affiche le plateau de jeux avec les pions correspondant et les deplacements possible pour le pion demander
	 * en transformant le tableau de int envoyer en parametre en ascii
	 * @param pDeplacements un tableau de deplacement de 8 par 3 indiquant tout les endrois ou le joueur peut aller
	 * @param pPosPion les coordonee ligne et colonne du pion que le joueur veut bouger
	 */
	public void mAfficherDeplacements(int[][] pDeplacements,int[] pPosPion)
	{
		String[][] myTab = new String[11][11];
		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{				
				if( this.aPlateau[l][c] == -1) // Noir
				{
					myTab[l][c] = "(Noir )\t";
				}
				else if( this.aPlateau[l][c] == 0) // Case vide
				{
					myTab[l][c] = "(     )\t";
				}
				else if( this.aPlateau[l][c] == 1 ) // Blanc
				{
					myTab[l][c] = "(Blanc)\t";
				}
				else if (this.aPlateau[l][c] == 2) // Zen l'initi�
				{
					myTab[l][c] = "( Zen )\t";
				}
				
			}
		}
		
		myTab[ pPosPion[0] ][ pPosPion[1] ] = "[" + myTab[ pPosPion[0] ][ pPosPion[1] ].substring(1,6) + "]\t";

		
		for (int i = 0; i < 8 ; i++)
		{
			if (pDeplacements[i][2] == 1)
			{
				myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "[[" + myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ].substring(2,5) + "]]\t";
			}
			else if( pDeplacements[i][2] == 3 )
			{
				myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "{{eat}}\t";
			}
		}
		
		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{	
				System.out.print(myTab[l][c] );
			}
			System.out.println( (11-l) + "\t\n" );
		}
		System.out.println("   A       B       C       D       E       F       G       H       I      J      K    ");
		System.out.println("________________________________________________________________________________________");

	}
	
	/**
	 * Recupere un string et le renvoie sous forme d'un tableau de int a deux valeurs comprises entre 0 et 10
	 * Si le string ne correspond pas pour etre transformer alors le tableau renvoyer est {-1,-1}.
	 * @param pPos un string normalement sous forme "A5" pour A = colonne et 5 = ligne
	 * @return les ligne colonne de l'endrois voulue.
	 */
	public int[] mDechiffrePos( String pPos)
	{
		pPos =  pPos.toLowerCase(); // Supprimer les majuscules
		char[] cColonne = {'a','b','c','d','e','f','g','h','i','j','k'};
		int colonne = -1; // Si la colonne n'est pas dans le tableau de colonne return -1
		int ligne = - 1;
	
		
		// La taille de la chaine ne peux etre que de 2 ou 3, si elle ne correspond pas en taille, pas la peine de tester  ( A1 -> 2  //  B11 -> 3 )
		if (pPos.length() == 2 || pPos.length() == 3 )  
		{
			char col = pPos.charAt(0);

			for(int i = 0; i < cColonne.length; i++)
			{
				if ( col == cColonne[i] ) // Si elle correspond � une vraie colonne ! 
				{
					colonne = i;
				}
			}
	
			try
			{
				ligne = Integer.parseInt( pPos.substring(1) ) - 1;  // -1 car les tableaux commencent � 0 
				ligne = 10 - ligne; // 10 - ligne car les lignes sont compt� � l'envers sur un echiquier
				if ( !(ligne >= 0 && ligne <= 10) ) // Si la ligne est entre 0 et 10 
				{
					colonne = -1; 
					ligne = - 1;
				}
			}
				catch (NumberFormatException e) 
			{
					colonne = -1; 
					ligne = - 1;
					new Log("mDechiffrePos : tryCatch - NumberFormatException");
			}
	
		}
		int[] ret = {ligne,colonne}; 
		return ret;
	}
	
	/**
	 * Demande une position a l'utilisateur jusqu'a ce que cette position fasse partie des cases du plateau 
	 * Ensuite une 2eme methode testera si cette position correspond a un pion du joueur.
	 * @return tableau de int sous forme tab[0] = ligne tab[1] = column.
	 */
	public int[] mAskPos()
	{
		int[] ret = null;
		System.out.println("1) Menu \t2) Sauvegarder \t3) Regles \t4)Quitter");
		System.out.println("Entrez une position sous la forme \"A1\" jusqu'a \"K11\" ");
		String ec;
		
		do
		{
			System.out.print("Bouger le pion en [");
			ec = sc.nextLine();		// ec pour entr�e clavier		
			mBoutonIg( ec, "ask Pion"); // Dans le cas ou l'entr�e clavier utilisateur ne serait pas une position, ni une erreur, alors il peut vouloir acceder � un des menu, sauvegarde ou autre, il faudras ensuite revenir ici 
			ret = mDechiffrePos(ec);
		}while (ret[0] == -1 && ret[1] == -1); // Continue de redemander tant que le programme n'arrive pas � dechiffrer.
		
		return ret;
	}
	
	/**
	 * Une fois que le joueur a donner une position pour se deplacer, verifier que cette position correspond � un de ses pion ou au Zen.
	 * @return La position ou le joueur veux se deplacer
	 */
	public int[] mVerifPos()
	{
		int[] pos;
		do 
		{
			pos = mAskPos();
			System.out.println(pos[0] + "\t" + pos[1]);//============================================
		}while( this.aPlateau[ pos[0] ][ pos[1] ] != this.aTurnToPlay
			 && this.aPlateau[ pos[0] ][ pos[1] ] != this.aZen.getZenColor() ); 
		// Continuer de demander une nouvelle position tant que :
		// La couleur du pion selectionn�e par le joueur n'est pas la sienne
		// OU La couleur du pion selectionn�e par le joueur n'est pas celle du 

		return pos; 
	}

	/**
	 * Demande en boucle a l'utilisateur une position ou bouger son pion
	 * L'uttilisateur peut aussi aller au menu sauvegarder aller au regles quitter ou annuler le pion selectionee
	 * Si le joueur deplace le Zen, cette methode le met a jour
	 * @param pMove le tableau contenant les deplacements possible du pion
	 * @return la coordonnee choisis par le pions
	 */
	public int[] mAskMove(int[][] pMove)
	{
		System.out.println("1) Menu \t2) Sauvegarder \t3) Regles \t4)Quitter \t 5) Annuler");
		System.out.println("Entrez un deplacement sous la forme \"A1\" , \"K11\" ");
		
		String ec;
		boolean exitLoop = false;
		int[] ret;
		
		do
		{
			System.out.print("Bouger a la case: [");
			ec = sc.nextLine();		// ec pour entr�e clavier		
			mBoutonIg( ec, "ask Move"); // Dans le cas ou l'entr�e clavier utilisateur ne serait pas une position, ni une erreur, alors il peut vouloir acceder � un des menu, sauvegarde ou autre, il faudras ensuite revenir ici 
			ret = mDechiffrePos(ec);
			
			if ( ret[0] != -1  ) // Si l'entree clavier est une reel position
			{
				for (int i = 0; i< 8; i++) // Pour chaqu'un des deplacement possible pour mon pion
				{
					if ( pMove[i][0] == ret[0] &&  pMove[i][1] == ret[1] ) // Si la position envoyer par l'uttilisateur fait partie des deplacement possible du pion
					{
						if ( pMove[i][2] == 1 ) // Si le deplacement est possible d'apres le tableau de deplacement
						{
							exitLoop = true; // Alors on peut sortir de la boucle (l'utilisateur a rentrer une position valide
						}
						else if ( pMove[i][2] == 3 ) // Si le pion bouger est le zen
						{
							this.aZen.mRefreshZen(pMove[i][0], pMove[i][1], this.aNoTurn);
							exitLoop = true; // Alors on peut sortir de la boucle (l'utilisateur a rentrer une position valide
						}
					}
				}
			}
		}while ( !exitLoop ); // Continue de redemander tant que l'utilisateur n'entre pas un vrais deplacement

		
		return ret;
	}
	
	/**
	 * Lorceque le joueur est en jeux il peut choisir de demander plusieurs information
	 * Sauvegarder, quitter, retourner au menu ou acceder au regles
	 * Cette methode recupere le choix de l'utilisateur et le fais acceder a son emplacement choisi
	 * (Action bizarre si le joueur retourne au menu depuis le jeux)
	 * @param pChoix Recupere en string l'action donner par l'uttilisateur.
	 * @param pFrom Permetant de savoir si le joueur peut annuler son action ou non ce String peut etre egale a "ask Move" ou "ask Pos"
	 */
	public void mBoutonIg(String pChoix, String pFrom)
	{
		int choix;
		try 
		{
			choix = Integer.parseInt( pChoix );
			if (choix == 1) // Retour au menu
			{
				System.out.println("== Menu ==");
				mMenu();
			}
			else if (choix == 2) // Sauvegarder 
			{
				System.out.println("== Sauvegarder =="); // Bien sur sauvegarder n'est pas cod� ! 
				mSaveIg();
			}
			else if (choix == 3) // Acceder au regles
			{
				System.out.println("== Regles ==");
				mRules();
				mAfficherPlateau(); // Apres avoir vu les regles on veux revoir le plateau
			}
			else if (choix == 4) // Quitter le programme
			{
				System.out.println("== Quitter ==");
				System.exit(0); 
			}
			else if (choix == 5)
			{
				if ( pFrom.equals("ask Move") ) // Si on a deja demander une position
				{
					System.out.println("== Redemander une nouvelle pos ==");
					mTurn();
				}
			}
			
		}
		catch (NumberFormatException e)
		{	
			new Log("mBoutonIg : tryCatch - NumberFormatException");
		}
	}
	
	/**
	 * Fonction a executer en jeux pour ecraser une sauvegarde existante et sauvegarder la partie actuelle � la place
	 * Cette fonction charge les 5 sauvegarde existante ( meme si il n'y a pas de partie)
	 * Les reponses attendu sont entre 0 et 4 pour les sauvegarde et 5 pour annuler
	 * 
	 */
	public void mSaveIg()
	{
		System.out.println("Choisissez votre point de sauvegarde");
		for (int i = 0; i < 5; i++)
		{
			Load l = new Load(i);
			System.out.println("Save " + i + ": " + l.toString() );
		}
		
		System.out.println("5 : Annuler");
		int choix = -1;
		do 
		{
			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e)
			{
				new Log("mSaveIg : tryCatch - NumberFormatException");

			}				
		}while ( choix < 0 || choix > 5);
		
		if ( choix <= 4) // Si le choix n'est pas annuler, alors sauvegarder la partie
		{
			new Save(this.aPlateau, this.aMode , this.aZen, this.aTurnToPlay , this.aNoTurn, choix);
		}// Sauvegarde l'etat actuel de la partie !

		// Apres avoir fait nos action, recommencer le tour
			mTurn();
		
	}

	/** 
	 * Cette methode fonctionne de la m�me facon que mRules,
	 * Elle affiche la sauvegarde � l'indice i et le joueur peut choisir:
	 * De lancer la partie
	 * De supprimer la sauvegarde
	 * De retourner au menu
	 * De voir la sauvegarde suivante
	 * De voir la sauvegarde precedante
	 */
	public void mSaves()
	{
		
		String[] save = new String[5];

		
		
		int actualSave = 0;
		int choix = -1;

		do 
		{
			// Si le joueur clique sur soivant ou precedant on change l'indice
			if (choix == 1) 
			{
				actualSave --;
			}
			else if ( choix == 3)
			{
				actualSave ++;
			}
			
			// Si l'indice d�passe le nombre de sauvegarde ou est inf�rieur a 0 alors on l'inverse
			if (actualSave >= save.length )
			{
				actualSave = 0; 
			}
			else if (actualSave < 0)
			{
				actualSave = save.length - 1 ; 
			}
			
			save[actualSave] = mSaveToString(actualSave);

			System.out.println("Sauvegarde no:" + actualSave + "\n" + save[actualSave] + "\n\n" + " 1: Precedent \t 2: Retour \t 3: Suivant \t 4: supprimer \t 5: continuer");

			// Si le joueur ne rentre pas un nombre, on evite de crash.
			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e){
				new Log("mSaves : tryCatch - NumberFormatException");
			} 
			
		}while ( choix != 2 && choix != 5); // Si le joueur veux faire retour OU jouer la sauvegarde, alors on sort de la boucle
				
		// Si le choix est egale a 2, la fonction s'arette et retourne a son lieux d'appel	
		
		// Si le choix est egale a 5, on charge la partie
		if (choix == 5)
		{
			new Log("Le joueur a charger la sauvegarde n�" + actualSave);
			Load loadGame = new Load(actualSave);

			this.aZen = loadGame.getZen();			// instance de Zen contenant toutes les information utile sur lui 
			this.aPlateau = loadGame.getPlateau(); 	// Avanc� du plateau de jeu
			this.aNoTurn = loadGame.getNoTurn(); 		// Numero du tour de jeu
			this.aTurnToPlay = loadGame.getNextPlayer(); 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
			this.aMode = loadGame.getMode();
			
			mTurn();
			
		}
	}

	/**
	 * Charge une sauvegarde grace a la classe Load puis transforme cette sauvegarde en un apercu du cour de la partie 
	 * @param pSave l'indice de la sauvegarde
	 * @return Apercu de la partie
	 */
	public String mSaveToString(int pSave)
	{
		System.out.println("La save " + pSave);
		Load loadGame = new Load(pSave);
		int[][] plateau = loadGame.getPlateau();
		String ret = "";
		
		// transforme le plateau en un block de caractere de 11 lignes par 11 colonnes 
		for (int l = 0 ; l< plateau.length ; l++)
		{
			for (int c = 0 ; c < plateau[l].length ; c++)
			{
				if (plateau[l][c] == -1 )
				{
					ret = ret + "3  ";
				}
				else
				{
					ret = ret + plateau[l][c] + "  ";
				}
			}	
			ret = ret + "\n";
		}
		
		ret = ret + "\n" + loadGame.toString();
		return ret;
	}

	/**
	 * Affiche les credits, demande a l'uttilisateur de rentrer 2 pour retourner au menu
	 */
	public void mCredits()
	{
		System.out.println("Jeux programm� sous Java grace � l'IDE Eclipse\n"
				+ "Par Allan Bernier dans le cadre du projet de programmation\n"
				+ "du DUT informatique de Vannes.\n");

		System.out.println("2 : Retour");
		int choix = -1;
		do 
		{
			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e)	{
				new Log("mCredits : tryCatch - NumberFormatException");
			}				
		}while ( choix != 2);
		
	}
}
