package newProject;

import java.util.Scanner;

public class HumanTerminal extends Human{
	Scanner sc;			// Interaction uttilisateur 
	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu
	int aTurnToPlay; 	// Indice du joueur qui dois jouer ( -1 = NOIR ou 1 = BLANC )
	int aMode;
	
	public HumanTerminal(Zen pZen, int[][] pPlateau, int noTurn) {
		super(pZen, pPlateau, noTurn);
	}

	
	/**
	 * Demande une position a l'utilisateur jusqu'a ce que cette position fasse partie des cases du plateau 
	 * Ensuite une 2eme methode testera si cette position correspond a un pion du joueur.
	 * @return tableau de int sous forme tab[0] = ligne tab[1] = column.
	 */
	public int[] mAskPos()
	{
		int[] ret = null;
		System.out.println("1) Menu \t2) Sauvegarder \t3) Regles \t4)Quitter");
		System.out.println("Entrez une position sous la forme \"A1\" jusqu'a \"K11\" ");
		String ec;
		
		do
		{
			System.out.print("Bouger le pion en [");
			ec = sc.nextLine();		// ec pour entr�e clavier		
			mBoutonIg( ec, "ask Pion"); // Dans le cas ou l'entr�e clavier utilisateur ne serait pas une position, ni une erreur, alors il peut vouloir acceder � un des menu, sauvegarde ou autre, il faudras ensuite revenir ici 
			ret = mDechiffrePos(ec);
		}while (ret[0] == -1 && ret[1] == -1); // Continue de redemander tant que le programme n'arrive pas � dechiffrer.
		
		return ret;
	}
	
	/**
	 * Lorceque le joueur est en jeux il peut choisir de demander plusieurs information
	 * Sauvegarder, quitter, retourner au menu ou acceder au regles
	 * Cette methode recupere le choix de l'utilisateur et le fais acceder a son emplacement choisi
	 * (Action bizarre si le joueur retourne au menu depuis le jeux)
	 * @param pChoix Recupere en string l'action donner par l'uttilisateur.
	 * @param pFrom Permetant de savoir si le joueur peut annuler son action ou non ce String peut etre egale a "ask Move" ou "ask Pos"
	 */
	public void mBoutonIg(String pChoix, String pFrom)
	{
		int choix;
		try 
		{
			choix = Integer.parseInt( pChoix );
			if (choix == 1) // Retour au menu
			{
				System.out.println("== Menu ==");
				mMenu();
			}
			else if (choix == 2) // Sauvegarder 
			{
				System.out.println("== Sauvegarder =="); // Bien sur sauvegarder n'est pas cod� ! 
				mSaveIg();
			}
			else if (choix == 3) // Acceder au regles
			{
				System.out.println("== Regles ==");
				mRules();
				mAfficherPlateau(); // Apres avoir vu les regles on veux revoir le plateau
			}
			else if (choix == 4) // Quitter le programme
			{
				System.out.println("== Quitter ==");
				System.exit(0); 
			}
			else if (choix == 5)
			{
				if ( pFrom.equals("ask Move") ) // Si on a deja demander une position
				{
					System.out.println("== Redemander une nouvelle pos ==");
					mTurn();
				}
			}
			
		}
		catch (NumberFormatException e)
		{	
			new Log("mBoutonIg : tryCatch - NumberFormatException");
		}
	}
	
	/**
	 * Recupere un string et le renvoie sous forme d'un tableau de int a deux valeurs comprises entre 0 et 10
	 * Si le string ne correspond pas pour etre transformer alors le tableau renvoyer est {-1,-1}.
	 * @param pPos un string normalement sous forme "A5" pour A = colonne et 5 = ligne
	 * @return les ligne colonne de l'endrois voulue.
	 */
	public int[] mDechiffrePos( String pPos)
	{
		pPos =  pPos.toLowerCase(); // Supprimer les majuscules
		char[] cColonne = {'a','b','c','d','e','f','g','h','i','j','k'};
		int colonne = -1; // Si la colonne n'est pas dans le tableau de colonne return -1
		int ligne = - 1;
	
		
		// La taille de la chaine ne peux etre que de 2 ou 3, si elle ne correspond pas en taille, pas la peine de tester  ( A1 -> 2  //  B11 -> 3 )
		if (pPos.length() == 2 || pPos.length() == 3 )  
		{
			char col = pPos.charAt(0);

			for(int i = 0; i < cColonne.length; i++)
			{
				if ( col == cColonne[i] ) // Si elle correspond � une vraie colonne ! 
				{
					colonne = i;
				}
			}
	
			try
			{
				ligne = Integer.parseInt( pPos.substring(1) ) - 1;  // -1 car les tableaux commencent � 0 
				ligne = 10 - ligne; // 10 - ligne car les lignes sont compt� � l'envers sur un echiquier
				if ( !(ligne >= 0 && ligne <= 10) ) // Si la ligne est entre 0 et 10 
				{
					colonne = -1; 
					ligne = - 1;
				}
			}
				catch (NumberFormatException e) 
			{
					colonne = -1; 
					ligne = - 1;
					new Log("mDechiffrePos : tryCatch - NumberFormatException");
			}
	
		}
		int[] ret = {ligne,colonne}; 
		return ret;
	}
	
	
	/**
	 * affiche les r�gles 1 par 1 avec un scaner pour passer de l'une a l'autre
	 * Si on envoit 1 au scaner il lit la r�gle precedent
	 * 2 il retourne a la derni�re fenetre d'ou il a ete appeler
	 * 3 il lit la regle suivante.
	 */
	public void mRules()
	{
		String[] sRules = {
				"Debut de la partie: \n"
				+ "Chaque joueur choisit une couleur blanc ou noir\n"
				+ "Le pion Zen est au centre du plateau\n"
				+ "Le joueur qui commence est tir� au sort.\n"
			,				
				"But du jeu: \n"
				+ "Le vainqueur est le premier joueur qui reussit a former une chaine continue\n"
				+ "avec la totalit� de ses pions y compris le Zen si celui-ci est encore en jeu.\n"
			,				
				"Deroulement de la partie: \n"
				+ "Chaque joueur deplace a son tour un pion de sa couleur ou le Zen en respectant 4\n"
				+ "regles tres simple."
			,				
				"Regle 1: \n"
				+ "Les pions se deplacent en ligne droite dans nimporte quelle\n"
				+ "direction (ligne, colonne, diagonales)\n"
				+ "Tout pions doit toujour se deplacer d'autant de cases qu'il y a de pions sur la ligne de\n"
				+ "deplacement choisie\n"
				+ "(Tout les pions y compris le pion deplace"
			,				
				"Regle 2: \n"
				+ "Tout pion peut passer par dessus un ou plusieur pions de sa couleur mais \n"
				+ "jamais par dessus ceux de son adversaire !"
			,				
				"Regle 3: \n"
				+ "Tout pion peut capturer un pion adverse en se placant sur la case occupe par le pion en respectant la regle 1"
			,				
				"Regle 4: \n"
				+ "a chaque coup, le Zen, pion commun a tous les joueurs peut �tre soit blanc, soit noir\n"
				+ "selon l'interet de celui qui joue "
			,				
				"Particularite autour du Zen:"
				+ "\ta) Lorcequ'il est deplacer par un joueur, son adversaire n'a pas\n"
				+ "le droit de le replacer sur la meme case au tour suivant\n"
				+ "\n"
				+ "\tb) Il est interdit de le deplacer si il ne se trouve pas en contact avec\n"
				+ "au moins un autre pion (blanc ou noir)"
			,				
				"Match Null: \n"
				+ "Si en fin de partie un joueur finis au meme coup, son graph et celui de son adversaire"				
			};
		
		
		int actualRule = 0;
		int choix = -1;

		do 
		{
			if (choix == 1) 
			{
				actualRule --;
			}
			else if ( choix == 3)
			{
				actualRule ++;
			}
			if (actualRule >= sRules.length )
			{
				actualRule = 0; 
			}
			else if (actualRule < 0)
			{
				actualRule = sRules.length - 1 ; 
			}
			System.out.println(sRules[actualRule] + "\n\n" + " 1: Precedent \t 2: Retour \t 3: Suivant");

			try
			{
				choix = Integer.parseInt( sc.nextLine() );				
			}
			catch (NumberFormatException e)
			{
				new Log("mRules : tryCatch - NumberFormatException");

			}				
		}while ( choix != 2 );
				
		// Si le choix est egale a 2, la fonction s'arette et retourne a son lieux d'appel		
		
	}
	
	
	/**
	 * Affiche le plateau de jeux avec les pions correspondant
	 * en transformant le tableau de int en parametre en ascii
	 */
	public  void mAfficherPlateau()// Plus tard les Lettres seront remplac� par des couleurs
	{

		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{
				if( this.aPlateau[l][c] == -1) // Noir
				{
					System.out.print("(Noir)\t");
				}
				else if( this.aPlateau[l][c] == 0) // Case vide
				{
					System.out.print("(     )\t");
				}
				else if( this.aPlateau[l][c] == 1 ) // Blanc
				{
					System.out.print("(Blanc)\t");
				}
				else if (this.aPlateau[l][c] == 2) // Zen l'initi�
				{
					System.out.print("( Zen )\t");
				}	
			}
			System.out.println( (11-l) + "\t\n" );
		}
		System.out.println("   A       B       C       D       E       F       G       H       I      J      K    ");
		System.out.println("________________________________________________________________________________________");

	}

	/**
	 * Affiche le plateau de jeux avec les pions correspondant et les deplacements possible pour le pion demander
	 * en transformant le tableau de int envoyer en parametre en ascii
	 * @param pDeplacements un tableau de deplacement de 8 par 3 indiquant tout les endrois ou le joueur peut aller
	 * @param pPosPion les coordonee ligne et colonne du pion que le joueur veut bouger
	 */
	public void mAfficherDeplacements(int[][] pDeplacements,int[] pPosPion)
	{
		String[][] myTab = new String[11][11];
		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{				
				if( this.aPlateau[l][c] == -1) // Noir
				{
					myTab[l][c] = "(Noir )\t";
				}
				else if( this.aPlateau[l][c] == 0) // Case vide
				{
					myTab[l][c] = "(     )\t";
				}
				else if( this.aPlateau[l][c] == 1 ) // Blanc
				{
					myTab[l][c] = "(Blanc)\t";
				}
				else if (this.aPlateau[l][c] == 2) // Zen l'initi�
				{
					myTab[l][c] = "( Zen )\t";
				}
				
			}
		}
		
		myTab[ pPosPion[0] ][ pPosPion[1] ] = "[" + myTab[ pPosPion[0] ][ pPosPion[1] ].substring(1,6) + "]\t";

		
		for (int i = 0; i < 8 ; i++)
		{
			if (pDeplacements[i][2] == 1)
			{
				myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "[[" + myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ].substring(2,5) + "]]\t";
			}
			else if( pDeplacements[i][2] == 3 )
			{
				myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "{{eat}}\t";
			}
		}
		
		for (int l = 0; l < 11 ; l++)
		{
			for (int c = 0; c < 11; c ++)
			{	
				System.out.print(myTab[l][c] );
			}
			System.out.println( (11-l) + "\t\n" );
		}
		System.out.println("   A       B       C       D       E       F       G       H       I      J      K    ");
		System.out.println("________________________________________________________________________________________");

	}
	

	

}
