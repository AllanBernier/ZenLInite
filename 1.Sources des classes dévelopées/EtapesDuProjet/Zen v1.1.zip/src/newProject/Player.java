package newProject;

public class Player {
	Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	int[][] aPlateau; 	// Avanc� du plateau de jeu
	int aNoTurn; 		// Numero du tour de jeu

	public Player(Zen pZen, int[][] pPlateau, int noTurn) 
	{
	}
	
	
	
	
	
	
}
