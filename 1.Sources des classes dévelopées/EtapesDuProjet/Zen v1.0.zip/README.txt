@Author BernierAllan

** Les regles du jeux dans sujet.pdf **
Lancez le main.class pour démarer le jeux.


