package newProject;

import file.Log;
import file.Save;

public class Game {
	
	private Vue aVue; // Graphique

	private PlayerIA aIa;
	
	private IPlayable aWhite;
	private IPlayable aBlack;
	
	private IPlayable aCurrent;
	
	private Zen aZen;			// instance de Zen contenant toutes les information utile sur lui 
	private int[][] aPlateau; 	// Avanc� du plateau de jeu
	private int aNoTurn; 		// Numero du tour de jeu
	private Mode aMode;
	
	/**
	 * Dans le cas ou je commence un nouvelle partie, utiliser ce constructeur
	 * @param pVue le graphique 
	 * @param pMode le mode de jeu
	 */
	public Game(Vue pVue)
	{
		if (pVue != null)
		{
			this.aIa = new PlayerIA(0, null);
			this.aVue = pVue;
		}
		else
		{
			Log.mLog("Error : Game -> Constructeur erreur de parametres");
		}
	}
	
	/**
	 * Initialise les attribut d'une partie en fonction du mode 
	 * @param pMode le mode de jeux avec 1/Joue en Player vs IA, 2/ Joue en Player vs Player 3/ Joue en 2 Player vs 2 Player
	 * 
	 */
	public void mNewGame(Mode pMode)
	{
		if ( pMode == Mode.PvIA || pMode == Mode.PvP || pMode == Mode.PvP4Joueurs )
		{
			this.aMode = pMode;
			this.aPlateau = mInitPlateau();
			this.aZen = new Zen();
			this.aNoTurn = 0;
			switch(pMode)
	        {
		        case PvP: //Joue en Player vs IA
		        	aWhite = new PlayerIHM(1, aZen);
		        	aBlack = new PlayerIHM(-1, aZen);
		        break;
		        case PvIA: //Joue en Player vs Player
		        	aWhite = new PlayerIHM(1, aZen);
		        	aBlack = new PlayerIA(-1, aZen);
	
		        break;
		        case PvP4Joueurs: // Joue en 2 Player vs 2 Player
	
		        	aWhite = new PlayerIHM(1, aZen);
		        	aBlack = new PlayerIHM(-1, aZen);
		        break;
	        }
			
	    	this.aCurrent = aWhite;	
			this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
		}
		else
		{
			Log.mLog("Error : Game -> mNewGame(Mode pMode) erreur de parametres");
		}
	}
	
	public void mNewGame(Mode pMode, int[][] pPlateau, Zen pZen, int pNoTurn, int pTurnToPlay)
	{
		if ( (pMode == Mode.PvIA || pMode == Mode.PvP || pMode == Mode.PvP4Joueurs) && pPlateau != null && pZen != null && pNoTurn >= 0 && (pTurnToPlay == 1 || pTurnToPlay == -1) )
		{
			this.aMode = pMode;
			this.aPlateau = pPlateau;
			this.aZen = pZen;
			this.aNoTurn = pNoTurn;
			
			switch(pMode)
	        {
		        case PvP: //Joue en Player vs IA
		        	this.aWhite = new PlayerIHM(1, this.aZen);
		        	this.aBlack = new PlayerIHM(-1, this.aZen);
		        break;
		        case PvIA: //Joue en Player vs Player
		        	this.aWhite = new PlayerIHM(1, this.aZen);
		        	this.aBlack = new PlayerIA(-1, this.aZen);
	
		        break;
		        case PvP4Joueurs: // Joue en 2 Player vs 2 Player
	
		        	this.aWhite = new PlayerIHM(1, this.aZen);
		        	this.aBlack = new PlayerIHM(-1, this.aZen);
		        break;
	        }
			
	    	if (pTurnToPlay == 1)
	    	{
	    		this.aCurrent = this.aWhite;	
	    	}
	    	else
	    	{
	    		this.aCurrent = this.aBlack;
	    	}
	    			
	    	this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
		}
		else
		{
			Log.mLog("Error : Game -> mNewGame(Mode pMode, int[][] pPlateau, Zen pZen, int pNoTurn, int pTurnToPlay) erreur de parametres");
		}
	}
	
	/**
	 * Initialise un tableau a deux dimensions contenant les coordonee de chaque pions.
	 * @return Renvoie un tableau de int contenant les position de chaque pions au debut d'une partie.
	 */
	public int[][] mInitPlateau()
	{
		int ret[][] =  {{1 ,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,-1},//0
						{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//1
						{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//2
						{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//3
						{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//4
						{-1,0 ,0 ,0 ,0 ,2 ,0 ,0 ,0 ,0 ,-1},//5
						{0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,1 ,0 },//6
						{0 ,0 ,-1,0 ,0 ,0 ,0 ,0 ,-1,0 ,0 },//7 c 3 l 8
						{0 ,0 ,0 ,1 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },//8
						{0 ,0 ,0 ,0 ,-1,0 ,-1,0 ,0 ,0 ,0 },//9
						{-1,0 ,0 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,1 } //10
					}; //0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10	
		return ret;
		
	}
	
	/**
	 * Effectue le tour du joueur Humain actuel puis, si le mode est player vs ia, alors effectue le tour de l'ia.
	 * Puis avant de finir le tour, verifit que la partie n'est pas finis, si elle est finis, alors affiche l'ecran game over.
	 * @param pLine La ligne cliquer
	 * @param pColumn La column cliquer
	 */
	public void mCaseClicked(int pLine ,int pColumn)
	{
		if ( pLine >= 0 && pLine < 11 && pColumn >= 0 && pColumn < 11)
		{			
			Log.mLog("La case cliqu� est : [" + pLine + "][" + pColumn + "]");
	
			// Verifier que le joueur courrant est un Humain
			// Recuperer le dynamique de aCurrent puis terter qu'il soit un newProject.PlayerHumanGraphique
	
			mHumanTurn(pLine, pColumn);
			
			System.out.println(this.aMode);
			if ( this.aMode == Mode.PvIA )
			{
				if (this.aCurrent.getClass() == this.aIa.getClass())
				{
					mIaTurn();
				}
			}
			
			boolean whiteWin = GameOver.mIsOver(this.aWhite.getColor() , this.aZen, this.aPlateau);
			boolean blackWin = GameOver.mIsOver(this.aBlack.getColor() , this.aZen, this.aPlateau);
			if ( whiteWin || blackWin )
			{
				Log.mLog("Le joueur blanc a : " + (whiteWin ? "Gagner" : "Perdu" ));
				Log.mLog("Le joueur blanc a : " + (blackWin ? "Gagner" : "Perdu" ));
				this.aVue.mDrawMenu();
			}
			
		}
		else
		{
			Log.mLog("Error : Game -> mCaseClicked(int pLine ,int pColumn) erreur de parametres");
		}
	}
	
	/**
	 * Initialise un nouveau tour,
	 * Augmente le numero de tour de 1,
	 * Change le joueur courant avec le joueur qui dois jouer.
	 */
	public void mNewTurn()
	{
		// Le tour de jeu augente de 1
		this.aNoTurn ++;
		this.aBlack.setNoTurn(this.aNoTurn);
		this.aWhite.setNoTurn(this.aNoTurn);
		
		// On change de joueur courant, puis, on redemande les info que le joueur a changer
		if ( this.aCurrent == this.aBlack)
		{
			this.aCurrent = this.aWhite;
			Log.mLog("Au tour du joueur Blanc");
		}
		else if (this.aCurrent == this.aWhite)
		{
			this.aCurrent = this.aBlack;
			Log.mLog("Au tour du joueur Noir");
		}
	}

	/**
	 * Effectue le tour de l'IA, selectionne le pion a deplacer puis le deplace, 
	 * L'equivalant pour le joueur humain est la methode mCaseClicked(int pLine ,int pColumn)
	 */
	public void mIaTurn()
	{
		this.aCurrent.mPlay(this.aZen , this.aPlateau, this.aNoTurn );
		
		try 
		{
		    Thread.sleep(500);
		} 
		catch (InterruptedException e) {}
		
		int[] pion = this.aCurrent.getPion();
		int[][] move = Move.getMove(this.aPlateau, pion[0], pion[1], this.aCurrent.getColor());
		this.aVue.mDrawGame(PlateauToString(this.aPlateau, move, pion), 0, 0, true);
		
		try 
		{
		    Thread.sleep(500);
		} 
		catch (InterruptedException e) {}
		
		int[] where = this.aCurrent.getWhere();
				
		this.aPlateau[ where[0] ][ where[1] ] = this.aPlateau[  pion[0] ][  pion[1] ];
		this.aPlateau[  pion[0] ][  pion[1] ] = 0;
		System.out.println(where[0] + "  " + where[1] + "  " + pion[0] + "  " + pion[1] );
		
		
		this.aVue.mDrawGame(this.PlateauToString(this.aPlateau), 0, 0, true);
		mNewTurn();
	}
	
	public void mHumanTurn(int pLine, int pColumn)
	{
		if ( pLine >= 0 && pLine < 11 && pColumn >= 0 && pColumn < 11)
		{	
			PlayerIHM human = new PlayerIHM(0, null);
			
			if ( aCurrent.getClass() == human.getClass())
			{
				aCurrent.isClicked(pLine, pColumn);
				aCurrent.mPlay(aZen, aPlateau,this.aNoTurn );
				
				if (this.aCurrent.getSelected() )
				{
					
					int[] pion = aCurrent.getPion();
		
					if ( !this.aCurrent.getEndTurn() )
					{
						int[][] move = Move.getMove(this.aPlateau, pion[0], pion[1], this.aCurrent.getColor());
						
						if( this.aPlateau[ pion[0] ][ pion[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
						{
							move = this.aZen.mZenMove( this.aPlateau , move , this.aNoTurn);
						}
						
						this.aVue.mDrawGame( PlateauToString( this.aPlateau, move, pion  ), 0, 0, true);
					}
					else 
					{
						
						int[] where = aCurrent.getWhere();
						
						this.aPlateau[ where[0] ][ where[1] ] = this.aPlateau[ pion[0] ][ pion[1] ]; // On bouge le pion 
						this.aPlateau[ pion[0] ][ pion[1] ] = 0; // L'ancienne case du pion est vide.
						this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
						
						if( this.aPlateau[ where[0] ][ where[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
						{
							System.out.println("========== "+ where[0] + " ===== "+ where[1] + " ==========="+ pion[0] + " ===== "+ pion[1] + "===========");
							this.aZen.mRefreshZen(where[0], where[1], this.aNoTurn );
						}
						
						Log.mLog("Deplacement du pion " + ( (this.aCurrent.getColor() == 1) ? "Blanc" : "Noir") + " de la case [" + pion[0] + "][" + pion[1] + "] � [" + where[0] + "][" + where[1] + "]" );
						this.aCurrent.setNewTurn();
						mNewTurn();
					}
				}
				else
				{
					this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
				}
			
			}
		
		}
		else
		{
			Log.mLog("Error : Game -> mHumanTurn(int pLine, int pColumn) erreur de parametres");
		}
	}
	
	/**
	 * Renvoie le plateau de jeux en un tableau de string sans aucun pion selectionn�e.
	 * @param pPlateau l'etat actuel du jeux
	 * @return Le plateau de jeux graphiquement beau.
	 */
	public String[][] PlateauToString(int[][] pPlateau)
	{
		if (pPlateau != null && pPlateau.length == 11 && pPlateau[0].length == 11 )
		{
			String[][] myTab = new String[11][11];
			
			for (int l = 0; l < pPlateau.length; l++)
			{
				for (int c = 0; c < pPlateau.length; c++)
				{
					if (pPlateau[l][c] == 0 )
					{
						myTab[l][c] = "";
					}
					else if (pPlateau[l][c] == 1 )
					{
						myTab[l][c] = "Blanc";
					}
					else if (pPlateau[l][c] == -1 )
					{
						myTab[l][c] = "Noir";
					}
					else if (pPlateau[l][c] == 2 )
					{
						myTab[l][c] = "Zen";
					}
				}			
			}
			return myTab;
		}
		else
		{
			Log.mLog("Error : Game -> PlateauToString(int[][] pPlateau) erreur de parametres");
		}
		return null;
	}	
	
	/**
	 * Renvoie le plateau de jeux en un tableau de string avec le pion selectionn�e et les case de d�placement possible affich�e
	 * @param pPlateau l'etat actuel du jeux
	 * @return Le plateau de jeux graphiquement beau.
	 */
	public String[][] PlateauToString(int[][] pPlateau, int[][] pDeplacements,int[] pPosPion)
	{
		if (pPlateau != null && pPlateau.length == 11 && pPlateau[0].length == 11 && pDeplacements != null && pDeplacements.length == 8 && pDeplacements[0].length == 3)
		{
			String[][] myTab = new String[11][11];
			for (int l = 0; l < 11 ; l++)
			{
				for (int c = 0; c < 11; c ++)
				{				
					if( pPlateau[l][c] == -1) // Noir
					{
						myTab[l][c] = "Noir";
					}
					else if( pPlateau[l][c] == 0) // Case vide
					{
						myTab[l][c] = "";
					}
					else if( pPlateau[l][c] == 1 ) // Blanc
					{
						myTab[l][c] = "Blanc";
					}
					else if (pPlateau[l][c] == 2) // Zen l'initi�
					{
						myTab[l][c] = " Zen";
					}
					
				}
			}
			
			myTab[ pPosPion[0] ][ pPosPion[1] ] = "[" + myTab[ pPosPion[0] ][ pPosPion[1] ] + "]";
	
			
			for (int i = 0; i < 8 ; i++)
			{
				if (pDeplacements[i][2] == 1)
				{
					myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "[[" + myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] + "]]";
				}
				else if( pDeplacements[i][2] == 3 )
				{
					myTab[ pDeplacements[i][0] ][ pDeplacements[i][1] ] = "{{eat}}";
				}
			}
			
			return myTab;
		}
		else
		{
			Log.mLog("Error : Game -> PlateauToString(int[][] pPlateau, int[][] pDeplacements,int[] pPosPion) erreur de parametres");
		}
		return null;
	}

	/**
	 * Si l'utilisateur consultais les r�gles, effectue l'action du click sur le bouton retour:
	 * Retourne a la page jeu 
	 * regarde si l'utilisateur avais selectionnee un pion -> affiche le pion selectionnee
	 * Sinon n'affiche pas de pion selectionn�e
	 */
	public void mRulesBack()
	{
		if (this.aCurrent.getSelected() )
		{
			int[] pion = aCurrent.getPion();
			
			int[][] move = Move.getMove(this.aPlateau, pion[0], pion[1], this.aCurrent.getColor());
			
			if( this.aPlateau[ pion[0] ][ pion[1] ] == this.aZen.getZenColor() ) // Si le deplacement concerne le Zen
			{
				move = this.aZen.mZenMove( this.aPlateau , move , this.aNoTurn);
			}	
			this.aVue.mDrawGame( PlateauToString( this.aPlateau, move, pion  ), 0, 0, true);
		}
		else
		{
			this.aVue.mDrawGame( PlateauToString( this.aPlateau ), 0, 0, true);
		}
		
		
	}
	
	
	/**
	 * Sauvegarde la partie actuelle dans le fichier correspondant au parametre envoyer.
	 * @param pSave valeur comprise entre 0 et 4.
	 */
	public void mSave(int pSave)
	{
		int noSave = pSave - 48;
		if (noSave >= 0 && noSave < 5)
		{		
			Save.mSaveGame(this.aPlateau, this.aMode, this.aZen, this.aCurrent.getColor() , this.aNoTurn, noSave);
			System.out.println(pSave + " NO DE SAVE ");
		}
		else
		{
			Log.mLog("Error : Game -> mSave(int pSave) erreur de parametres");
		}
	}
}







